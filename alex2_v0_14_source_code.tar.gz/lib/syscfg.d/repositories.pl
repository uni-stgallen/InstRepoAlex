# to disable a repository called "epapers" uncomment this line
# $c->{repository}->{epapers}->{disabled} = 1;
