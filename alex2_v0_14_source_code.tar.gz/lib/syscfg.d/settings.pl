# this file contains general settings for EPrints

# the operating system account user name and group name to use
#$c->{user} = 'eprint';
#$c->{group} = 'eprint';

# hostname of the SMTP (mail) server to send email with
#$c->{smtp_server} = 'smtp';
