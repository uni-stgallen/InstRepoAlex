
$c->{defaultlanguage} = 'en';

$c->{languages} = [ 'en' ];

