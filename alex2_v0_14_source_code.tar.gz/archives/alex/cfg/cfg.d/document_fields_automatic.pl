
$c->{set_document_automatic_fields} = sub
{
	my( $doc ) = @_;
};
