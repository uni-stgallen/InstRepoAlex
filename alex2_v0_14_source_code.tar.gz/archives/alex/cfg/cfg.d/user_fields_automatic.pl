
$c->{set_user_automatic_fields} = sub
{
	my( $user ) = @_;

	if( !$user->is_set( "frequency" ) )
	{
		$user->set_value( "frequency", "never" );
	}

	if ( !$user->is_set( "letter" ) && $user->is_set( "name" ) )
	{
		my $name = $user->get_value( "name" );
		if ( $name && $name->{family} )
		{
			my $letter = substr $name->{family}, 0, 1;
			$user->set_value( "letter", lc($letter) );
		}
	}
};
