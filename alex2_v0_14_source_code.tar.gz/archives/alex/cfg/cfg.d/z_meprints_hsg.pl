######################################################################
#
#  HSG customisations for MePrints configuration - v1.4.3
#
######################################################################


# Allow repo.ac.uk/profile/XYZ urls
#$c->{rewrite_exceptions} = [] unless( defined $c->{rewrite_exceptions} );
#push( @{$c->{rewrite_exceptions}}, "/profile/" );

# Set to "1" to use username eg repository.ac.uk/profile/sf2 instead of userid repository.ac.uk/profile/1234
$c->{meprints_profile_with_username} = 1;

# Maps the default EPrints' Profile page to MePrints'
$c->{plugins}->{"Screen::User::View"}->{appears}->{key_tools} = undef;
$c->{plugin_alias_map}->{"Screen::User::View"} = "Screen::User::Homepage_Alex";

# Use MePrints' homepage as first screen after logging in
$c->{plugins}->{"Screen::FirstTool"}->{params}->{default} = "User::Homepage_Alex";


$c->{plugins}->{"Screen::Login"}->{appears}->{key_tools} = undef;
$c->{plugins}{"MePrints::Widget::IRS2DownloadsGraph"}{params}{disable} = 0;
$c->{plugins}{"MePrints::Widget::IRStats::DownloadGraph"}{params}{disable} = 1;
$c->{plugins}{"Screen::User::Homepage"}{params}{disable} = 1;
$c->{plugins}{"Screen::User::Homepage_Alex"}{params}{disable} = 0;

# Handler to server (external) profile pages
$c->add_trigger( EP_TRIGGER_URL_REWRITE, sub
{
        my( %args ) = @_;

	my( $uri, $rc, $request ) = @args{ qw( uri return_code request ) };
        
	if( defined $uri && ( 
			($uri =~ m#^/profile/(.*)$# ) || 
			($uri =~ m#^/persons/(.*)$# ) || 
			($uri =~ m#^/publications/(.*)$# ) || 
			($uri =~ m#^/projects/(.*)$# )  
		) )
	{
                $request->handler('perl-script');
                $request->set_handlers(PerlResponseHandler => [ 'EPrints::Plugin::MePrints::MePrintsHandler' ] );
		${$rc} = EPrints::Const::OK;
	}

        return EP_TRIGGER_OK;

}, priority => 100 );


# Handler to set the alex_user_id for new accounts 
$c->add_dataset_trigger( "user", EPrints::Const::EP_TRIGGER_CREATED, sub { 
        my( %params ) = @_; 

        my $repo = $params{repository}; 
        my $user = $params{dataobj}; 

	my $id = $user->get_id();
	$user->set_value( "alex_user_id", $id );
	$user->commit();
} ); 


# Add extra metadata fields for user profiles
@{ $c->{fields}->{user} } = ( @{ $c->{fields}->{user} }, (
	{ 'name' => 'alex_user_id', 'type' => 'alexbrowseid', },
	{ 'name' => 'alex_url_name', 'type' => 'id', },
	{ 'name' => 'ppm_human_id', 'type' => 'id', },
	{ 'name' => 'hsg_entity_id', 'type' => 'id', },
	{ 'name' => 'security_token', 'type' => 'id', volatile => 1, text_index => 0, sql_index => 0, can_clone => 0, show_in_html => 0, export_as_xml => 0 },
#	{ 'name' => 'institute', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3,},
	{ 'name' => 'street', 'type' => 'text', },
	{ 'name' => 'post_code', 'type' => 'text', },
	{ 'name' => 'city', 'type' => 'text', },
	{ 'name' => 'phone', 'type' => 'text', },
	{ 'name' => 'fax', 'type' => 'text', },
	{ 'name' => 'cite_default', 'type' => 'set', 
		'options' => [
			   'HSG',
			 ],
		'input_style' => 'short',
	},
	{ 'name' => 'linkedin', 'type' => 'url', },
	{ 'name' => 'xing', 'type' => 'url', },
	{ 'name' => 'twitter', 'type' => 'text', },
	{ 'name' => 'skype', 'type' => 'text', },
	{ 'name' => 'blog', 'type' => 'url', },
	{ 'name' => 'gs', 'type' => 'url', },
	{ 'name' => 'repec', 'type' => 'url', },
	{ 'name' => 'ssrn', 'type' => 'url', },
	#{ 'name' => 'add_info', 'type' => 'longtext', 'render_value' => 'EPrints::MePrints::render_first_n_chars',},
	{ 'name' => 'add_info', 'type' => 'longtext', },
	{ 'name' => 'publication_name', 'type' => 'name', hide_honourific => 1, hide_lineage => 1, family_first => 1, },

	{ 'name' => 'main_focus', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 1, render_single_value => 'render_markup' },
	{ 'name' => 'main_research', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 1, render_single_value => 'render_markup' },
	{ 'name' => 'further_research', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3, render_single_value => 'render_markup' },
	{ 'name' => 'education', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3, render_single_value => 'render_markup' },
	{ 'name' => 'former_positions', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3, render_single_value => 'render_markup' },
	{ 'name' => 'boards', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3, render_single_value => 'render_markup' },
	{ 'name' => 'teaching', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3, render_single_value => 'render_markup' },
	{ 'name' => 'projects', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3, render_single_value => 'render_markup' },
	{ 'name' => 'affiliations', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3,  },
	{ 'name' => 'awards', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3, render_single_value => 'render_markup' },
	{ 'name' => 'spin_offs', 'type' => 'text', 'multiple' => 1, 'input_cols' => 30, 'input_boxes' => 3, render_single_value => 'render_markup' },
#	{ name => 'subjects', type => 'subject', multiple => 1, top => 'subjects', browse_link => 'subjects', },
	{ name => 'divisions', type => 'subject', multiple => 1, top => 'divisions', browse_link => 'divisions', },

));

$c->{user_profile_page_metadata} = [qw/
	fax
	linkedin
	xing
	twitter
	skype
	blog
	gs
	repec
	ssrn
	add_info
	main_focus
	main_research
	further_research
	education
	former_positions
	boards
	teaching
	projects
	affiliations
	awards
	spin_offs
	
/];

#@{$c->{browse_views}} = (@{$c->{browse_views}}, (
#        {
#                id => "profiles",
#		dataset => "public_profile_users",
#                menus => [
#                        {
#                                fields => [ "name" ],
#				hideempty => 1,
#                                reverse_order => 0,
#                                allow_null => 0,
#                                new_column_at => [10,10],
#                        }
#                ],
#                order => "name",
#                variations => [	"DEFAULT", "dept" ],
#        }
#));


{
# Package for extensions to EPrints::Script::Compiled
package EPrints::Script::Compiled;

use strict;

sub run_render_user_institute_old
{
        my( $self, $state, $user, $field ) = @_;

        if( ! $user->[0]->isa( "EPrints::DataObj::User" ) )
        {
                $self->runtime_error( "Can only call render_user_institute() on a user object not ".  ref($user->[0]) );
        }

        my $repo = $user->[0]->repository;
	my $chunk = $repo->make_doc_fragment;
	my $values = $user->[0]->get_value( "institute" );
	return [ $chunk, "XHTML"  ] unless( $values );
	my $value = $values->[0]; 
	return [ $chunk, "XHTML"  ] unless( $value );
	my @vals = split ":", $value;
	my $inst = $vals[-1];	

	if ( $inst )
	{
		if ( $field && $field->[0] )
		{
			$chunk->appendChild( $repo->make_text( " - " ) );
		}
		$chunk->appendChild( $repo->make_text( $inst ) );
	}

        return [ $chunk, "XHTML"  ];
}

sub run_render_user_divisions
{
        my( $self, $state, $user, $field ) = @_;

        if( ! $user->[0]->isa( "EPrints::DataObj::User" ) )
        {
                $self->runtime_error( "Can only call render_user_institute() on a user object not ".  ref($user->[0]) );
        }
        my $repo = $user->[0]->repository;
	my $chunk = $repo->make_doc_fragment;
	my $divisions = $user->[0]->get_value( "divisions" );
	return [ $chunk, "XHTML"  ] unless( $divisions );

	my $subj_ds = $repo->dataset( "subject" );
	my $lang_id = $repo->{lang}->get_id;
	$lang_id = "de" unless $lang_id;
	my $first = 1;				
	foreach my $division ( @$divisions )
	{
		my $subj = $subj_ds->dataobj( $division );
		next unless $subj; 
		my $names = $subj->get_value( "name" );
		next  unless $names;

		my $default = $names->[0]->{name};
		foreach my $entry ( @$names )
		{
			if ( $entry->{name} && $entry->{lang} && $entry->{lang} eq $lang_id )
			{
				$chunk->appendChild( $repo->make_text( ", " ) ) unless $first; 
				$chunk->appendChild( $repo->make_text( $entry->{name} ) ); 
				$first = 0;
       			}
		}
	}
	
        return [ $chunk, "XHTML"  ];
}


sub run_has_profile_picture
{
	my( $self, $state, $user, $field ) = @_;

	my $has_pic = 0;
	if( ! $user->[0]->isa( "EPrints::DataObj::User" ) )
	{
		$self->runtime_error( "Can only call has_profile_picture() on a user object not ".  ref($user->[0]) );
	}

	my $size = 'preview';
	my $pic_path = $user->[0]->get_picture_path()."/$size.png";

	$has_pic = 1 if ( -e $pic_path );
	return [ $has_pic, "BOOLEAN"  ];
}

};



