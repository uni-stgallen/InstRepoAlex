
$c->{set_eprint_defaults} = sub
{
	my( $data, $repository ) = @_;

	$data->{type} = "article";
};

