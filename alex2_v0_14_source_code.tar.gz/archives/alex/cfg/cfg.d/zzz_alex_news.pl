#
# controls and content for the latest news div on the home page
#
# to switch the div on set the config item show_alex_hp_news to 1
# and then it is necessary to regenerate the static pages using
# .bin/generate_static alex
#
# if the static pages are not regenerated then the changes to this file will have no effect
#

$c->{show_alex_hp_news} = 1;

