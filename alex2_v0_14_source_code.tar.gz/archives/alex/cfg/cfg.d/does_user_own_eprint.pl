#
# does_user_own_eprint 
#

$c->{does_user_own_eprint} = sub
{               
        my( $repo, $user, $eprint ) = @_;
	return 1 if $user->get_id == $eprint->get_value( "userid" );

	my $alex_user_id = $user->get_value("alex_user_id");
	return 0 unless $alex_user_id;

	foreach my $contrib_type ( qw/ creators editors / )
	{
		my $contributors = $eprint->get_value( $contrib_type );
		foreach my $contributor ( @$contributors )
		{
			my $contrib_alex_id = $contributor->{"alex_user_id"};
			next unless $contrib_alex_id;
			return 1 if $contrib_alex_id eq $alex_user_id;
		}
	}
	return 0;
};


$c->{does_user_own_project} = sub
{               
        my( $repo, $user, $project ) = @_;

	my $project_user_id = $project->get_value("userid"); 
	my $alex_user_id = $user->get_value("alex_user_id");
	return 0 unless $alex_user_id;
	return 1 if $project_user_id && $project_user_id == $alex_user_id;

	my $contributors = $project->get_value( "contributors" );
	foreach my $contributor ( @$contributors )
	{
		my $contrib_alex_id = $contributor->{"alex_user_id"};
		next unless $contrib_alex_id;
		return 1 if $contrib_alex_id eq $alex_user_id;
	}

	# if the user is an editor then they can be treated as an owner
	# unless a restriction has been placed on them
	my $user_type = $user->get_value( "usertype" );
	return 0 unless $user_type eq "editor";
	my $project_institutes = $project->get_value( "divisions" );

	return 1 unless scalar @$project_institutes;

	# check the restrictions
	my $allowed_institutes = {};
	my $editperms = $user->get_value( "editperms" );

	return 1 unless scalar @$project_institutes;
	return 1 unless scalar @$editperms;

	foreach my $sv ( @$editperms )
	{
		my @terms = split /\|/, $sv;
		foreach my $term ( @terms )
		{
			if ( $term =~ /^divisions:divisions:ANY:EQ:(.+)$/ )
			{
				my @editor_divs = split( " ", $1);
				foreach my $div ( @editor_divs )
				{
					$allowed_institutes->{$div}++;
				}
			}
		}
	}
	return 1 unless scalar keys %$allowed_institutes;
	foreach my $project_div ( @$project_institutes )
	{
		return 1 if $allowed_institutes->{$project_div};
	}

	return 0;
};
 
{
package EPrints::DataObj::User;

sub editable_projects_list
{
	my( $self, %opts ) = @_;
	my $ds = $self->{session}->dataset( "project" );		
	$opts{dataset} = $ds if !defined $opts{dataset};
	$opts{satisfy_all} = 0;

	my $searchexp = $opts{dataset}->prepare_search( %opts );

	unless ( $self->get_value( "usertype" ) eq "admin" || $self->get_value( "usertype" ) eq "editor" )
	{
		$searchexp->add_field( $opts{dataset}->field( "userid" ), $self->id );
		$searchexp->add_field( $opts{dataset}->field( "contributors_alex_user_id" ), $self->id );
	}
	my $full_list =  $searchexp->perform_search;
	return $full_list unless $self->get_value( "usertype" ) eq "editor";
	 
	my $editperms = $self->get_value( "editperms" );
	return $full_list unless $editperms;

	my $allowed_institutes = {};
	foreach my $sv ( @$editperms )
	{
		my @terms = split /\|/, $sv;
		foreach my $term ( @terms )
		{
			if ( $term =~ /^divisions:divisions:ANY:EQ:(.+)$/ )
			{
				my @editor_divs = split( " ", $1);
				foreach my $div ( @editor_divs )
				{
					$allowed_institutes->{$div}++;
				}
			}
		}
	}
	return $full_list unless scalar keys %$allowed_institutes;
	
	my @ids;
	$full_list->map( sub {
		my( $session, $dataset, $project, $info ) = @_;
		my $project_institutes = $project->get_value( "divisions" );
		if ( $project_institutes && scalar @$project_institutes > 0 )
		{
			foreach my $project_div ( @$project_institutes )
			{
				if ( $allowed_institutes->{$project_div} )
				{
					push @ids, $project->get_id;
					return;
				}
			}
		}
		else
		{	
			push @ids, $project->get_id;
		}
	});

	return $ds->list( \@ids );
}


sub owned_projects_list
{
	my( $self, %opts ) = @_;
		
	$opts{dataset} = $self->{session}->dataset( "eprint" ) if !defined $opts{dataset};
	$opts{satisfy_all} = 0;

	my $searchexp = $opts{dataset}->prepare_search( %opts );

	$searchexp->add_field( $opts{dataset}->field( "userid" ), $self->id );
	$searchexp->add_field( $opts{dataset}->field( "contributors_alex_user_id" ), $self->id );
	my $list =  $searchexp->perform_search;

	return $list;
}



}




