#
# ALEX Version
#

$c->{alex_version_no}	= "v0.14";

