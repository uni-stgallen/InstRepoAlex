=begin

=for InternalDoc

CERIF 2008 Specification for EPrints 3.2
----------------------------------------

This file provides additional data sets for use with EPrints to support the core entities specified in CERIF 2008.

This does not cover all aspects of the CERIF semantics.

Based on CERIF 2008 1.0 (accessed 2010-01-25):
http://www.eurocris.org/cerif/cerif-releases/cerif-2008/

=end InternalDoc

=cut

my $accept = $c->{plugins}->{"Export::SummaryPage"}->{params}->{accept} ||= [];

push @$accept, qw( dataobj/project ); #dataobj/org_unit );

$c->{roles}->{"project-deposit"} = [
		"projects",
		"create_project",
		"project/create",
		"project/view:owner",
		"project/export:owner",
		"project/summary:owner",
		"project/destroy:owner",
		"project/deposit:owner",
		"project/edit:owner",
		"project/remove:owner",
		"project/details:owner",
		"project/history:owner",
		"project/messages:owner",
		"project/issues:owner",
		"project/use_as_template:owner",
		"project/derive_version:owner",
	
		"project/deletion/view:owner",
		"project/deletion/export:owner",
		"project/deletion/summary:owner",
		"project/deletion/details:owner",
		"project/deletion/history:owner",
		"project/deletion/messages:owner",
		"project/deletion/use_as_template:owner",
		"project/deletion/derive_version:owner",
];

$c->{roles}->{"project-editor"} = [
		"project/view:editor",
		"project/export:editor",
		"project/summary:editor",
		"project/destroy:editor",
		"project/deposit:editor",
		"project/edit:editor",
		"project/remove:editor",
		"project/details:editor",
		"project/history:editor",
		"project/messages:editor",
		"project/issues:editor",
		"project/use_as_template:editor",
		"project/derive_version:editor",

		"project/deletion/view:editor",
		"project/deletion/export:editor",
		"project/deletion/summary:editor",
		"project/deletion/details:editor",
		"project/deletion/history:editor",
		"project/deletion/messages:editor",
		"project/deletion/use_as_template:editor",
		"project/deletion/derive_version:editor",
];

$c->{roles}->{"project-staff-view"} = [
		"project/create",
		"project/view",
		"project/edit",
		"project/destroy",
		"project/summary",
		"project/export",
		"project/details",
		"project/history",

		"project/deletion/view",
		"project/deletion/summary",
		"project/deletion/export",
		"project/deletion/details",
		"project/deletion/history",

		"project/search/staff",
];

$c->{roles}->{"project-admin"} = [
		"project/destroy",
		"project/details",
		"project/edit",
		"project/export",
		"project/view",
];
	
push @{$c->{user_roles}->{admin}}, qw(
	project-deposit
	project-editor
	project-staff-view
	project-admin
);

push @{$c->{user_roles}->{editor}}, qw(

	project-deposit
);

	#project-staff-view
	#project-editor

push @{$c->{user_roles}->{user}}, qw(
	project-deposit
);


push @{$c->{public_roles}}, qw(
	+project/export
	+project/search
	+project/view
);

$c->{datasets}->{project} = {
	class => 'Cerif::Project',
	sqlname => 'project',
	datestamp => 'start',
	columns => [qw( title )],
	index => 1,
	import => 1,
	search => {
		simple => {
			search_fields => [{
				id => "q",
				meta_fields => [qw(
					title
					contributors_name
					description
				)],
			}],
			order_methods => {
				"bydate"  	 =>  "-start/title",
				"bytitle" 	 =>  "title",
				"byvalue"	 =>  "value/title",
			},
			default_order => "bydate",
			show_zero_results => 1,
			citation => "picresult",
		},
	},
};

#$c->{datasets}->{org_unit} = {
#	class => 'Cerif::OrganisationUnit',
#	sqlname => 'org_unit',
#	datestamp => 'start',
#	columns => [qw( title )],
#	index => 1,
#	import => 1,
#	search => {
#		simple => {
#			search_fields => [{
#				id => "q",
#				meta_fields => [qw(
#					title
#					acronym
#				)],
#			}],
#			order_methods => {
#				"bydate"  	 =>  "-start/title",
#				"bytitle" 	 =>  "title",
#			},
#			default_order => "bydate",
#			show_zero_results => 1,
#			citation => "result",
#		},
#	},
#
#};

$c->{project_summary_page_metadata} = [qw/
	acronym
	contributors
	datestamp
	divisions
	end
	eprints
	hsg_profile_area
	keywords
	methods
	funders
	partners
	principal
	projectid
	range
	reference_number
	status
	subjects
	topics
	type
	uri
/];


$c->{fields}->{project} = [] if !defined $c->{fields}->{project};
unshift @{$c->{fields}->{project}}, (
	{
		name => 'projectid',
		type => 'counter',
		sql_counter => 'projectid',
	},

	{ 	name=>"userid", 
		type=>"itemref", 
		datasetid=>"user", 
		required=>0 
	},

	{
		name => 'start',
		type => 'date',
	},

	{
		name => 'end',
		type => 'date',
	},

	{
		name => 'acronym',
		type => 'text',
		maxlength => 16,
	},

	{
		name => 'uri',
		type => 'url',
		maxlength => 128,
	},

	{
		name => 'title',
		type => 'text',
	},

	{
		'name' => 'contributors',
		'type' => 'dataobjref',
		datasetid => 'user',
		'multiple' => 1,
		'fields' => [
		{
			'sub_name' => 'type',
			'type' => 'namedset',
			set_name => "project_contributor_type",
		},
		{
			'sub_name' => 'name',
			'type' => 'name',
			required => 1,
			family_first => 1,
		},
		{
			'sub_name' => 'alex_user_id',
			#'type' => 'id',
			'type' => 'alexbrowseid',
			input_cols => 10,
			required => 0,
		},
		],
		render_input => "render_creators_input",
	},
	
	{
		name => 'partners',
		type => 'text',
		multiple => 1,
	},	

	{
		name => 'description',
		type => 'longtext',
		render_single_value => 'render_paras',
	},

	{
		name => 'keywords',
		type => 'longtext',
	},

#	{
#		name => 'org_units',
#		type => 'dataobjref',
#		datasetid => 'org_unit',
#		multiple => 1,
#		fields => [
#			{ sub_name=>"title", type=>"text", },
#		],
#	},
	{
		name => 'funders',
		type => 'subject',
		multiple => 1,
		top => 'funders',
		browse_link => 'project_funders',
	},


	{
		name => 'eprints',
		type => 'subobject',
		multiple => 1,
		datasetid => 'archive',
		dataset_fieldname => '',
		dataobj_fieldname => 'projects_id',
		export_as_xml => 0,
	},

#	{
#		name => 'relation',
#		type => 'compound',
#		multiple => 1,
#		fields => [
#			{
#				sub_name => 'type',
#				type => 'id',
#			},
#			{
#				sub_name => 'uri',
#				type => 'id',
#			},
#			{
#				sub_name => 'start',
#				type => 'time',
#			},
#			{
#				sub_name => 'end',
#				type => 'time',
#			},
#		]
#	},
	{
		name => 'range',
		type => 'set',
		options => [qw(
			institute
			school
			internal
			partners
			other_uni
			other_uni_plus
		)],
		input_style => 'medium',
	},
	{
		name => 'type',
		type => 'set',
		options => [qw(
applied
fundamental
consulting
industry
benchmarking
dissertation
habilitation
other
		)],
		input_style => 'medium',
	},

	{
		name => 'status',
		type => 'set',
		options => [qw(
scheduled
ongoing
completed
periodic
interrupted
aborted
		)],
		input_style => 'medium',
	},

#	{
#		name => 'hsg_research_area',
#		type => 'set',
#		options => [qw(
#business
#economics
#information
#law
#cultural
#social
#political
#education
#not
#none
#		)],
#		input_style => 'medium',
#	},

	{
		name => 'reference_number',
		type => 'text',
	},
	{
		name => 'principal',
		type => 'text',
	},

	# Currency amount field based on project dataset field of the same name from the github.com/eprints/funders (ROS) project 
	{
		name => "currency_amount",
		type => "compound",
		fields => [
                        {
				sub_name=>"currency",
			        type=>"namedset", 
				set_name=>"currencies",
				required=>0, 
				input_rows=>1,
                        },
                        {
                                sub_name => 'major',
                                type => 'int',
				input_cols => 8,
			},
			{
				sub_name => 'minor',
                                type => 'int',
				render_input => sub {
					my ( $self, $session, $value, $dataset, $staff, $hidden_fields, $obj, $basename )  = @_;
                                        if( !defined $value || length($value) == 0 ) { $value = "00"; }
                                        elsif( length($value) == 1 ) { $value = $value . "0"; }
					my $input_field = $session->render_input_field(
						class => "ep_form_text ep_project_currency_amount_minor",
						name => "c1_currency_amount_minor",
						value => $value,
						maxlength => 2,
						style => "width: 20px;",
						onkeypress => 'onkeypress="return EPJS_block_enter( event )',
					);
					my $frag = $session->make_doc_fragment;
					$frag->appendChild( $session->make_text(". "));
					$frag->appendChild( $input_field );
					return $frag;
				},
			},
		],
		render_value => sub {
			my( $session , $field , $value ) = @_;

                        if( !defined $value ) { return $session->make_doc_fragment; }
			if( $value->{major} =~ /^\d+$/ and length($value->{major}) > 3 )
                        {
                        	my $d = $value->{major};
                                my $human = "";
                                while( $d =~ s/(\d{3})$// )
                                {
                                	$human = ( $d ? ",$1" : "$1" ).$human;
                                }

                                $human = $d.$human if( $d );
                                $value->{major} = $human;
			}
			
			if( !defined $value->{minor} || length($value->{minor}) == 0 ) { $value->{minor} = "00"; }
			elsif( length($value->{minor}) == 1 ) { $value->{minor} = $value->{minor} . "0"; }
			elsif( length($value->{minor}) > 2 ) {
				my $rounding = "0.".substr($value->{minor}, 2);
                       		my $value->{minor} = substr($value->{minor}, 0, 2);
                               	if ($rounding >= 0.5) { $value->{minor}++; }
                        }
		 	my $currency_prefix = $session->phrase("currencies_prefix_".$value->{currency});
			my $currency_suffix = " (" . $session->phrase("currencies_suffix_".$value->{currency}) . ")";
                        my $display =  $currency_prefix . $value->{major} . "." . $value->{minor} . $currency_suffix || "";
                        return $session->make_text($display);
 		},	
	},

	{
		name => 'notes',
		type => 'longtext',
		render_single_value => 'render_paras',
	},
	{
		name => 'topics',
		type => 'longtext',
	},
	{
		name => 'methods',
		type => 'longtext',
	},
{
	name => 'hsg_profile_area',
	type => 'set',
	options => [qw(
		00
		01
		20
		21
		22
		30
		40
		none
	)],
	input_style => 'medium',
},

	{ name=>"datestamp", type=>"time", required=>0, import=>0,
		render_res=>"minute", render_style=>"short", can_clone=>0 },

	{ name => 'subjects', type => 'subject', multiple => 1, top => 'subjects', browse_link => 'subjects', },
	{ name => 'divisions', type => 'subject', multiple => 1, top => 'divisions', browse_link => 'divisions', },

);

#$c->{fields}->{org_unit} = [] if !defined $c->{fields}->{org_unit};
#unshift @{$c->{fields}->{org_unit}}, (
#	{
#		name => 'org_unitid',
#		type => 'counter',
#		sql_counter => 'org_unitid',
#	},
#
#	{
#		name => 'start',
#		type => 'date',
#	},
#
#	{
#		name => 'end',
#		type => 'date',
#	},
#
#	{
#		name => 'acronym',
#		type => 'text',
#		maxlength => 16,
#	},
#
#	{
#		name => 'title',
#		type => 'text',
#	},
#
#	{
#		name => 'uri',
#		type => 'url',
#		maxlength => 128,
#	},
#
#	{
#		name => 'res_act', # research activity
#		type => 'longtext',
#	},
#
#	{
#		name => 'keywords',
#		type => 'longtext',
#	},
#
#	{
#		name => 'projects',
#		type => 'subobject',
#		datasetid => 'project',
#		dataset_fieldname => '',
#		dataobj_fieldname => 'org_units_id',
#		multiple => 1,
#	},
#
#	{
#		name => 'relation',
#		type => 'compound',
#		multiple => 1,
#		fields => [
#			{
#				sub_name => 'type',
#				type => 'id',
#			},
#			{
#				sub_name => 'uri',
#				type => 'id',
#			},
#			{
#				sub_name => 'start',
#				type => 'date',
#			},
#			{
#				sub_name => 'end',
#				type => 'date',
#			},
#		]
#	},
#);

# strip out the native projects

#push @{$c->{fields}->{eprint}},
#	{
#		name => 'org_units',
#		type => 'dataobjref',
#		multiple => 1,
#		datasetid => 'org_unit',
#		fields => [
#			{ sub_name=>"title", type=>"text", },
#		],
#	};

if( !grep { $_->{name} eq "projects" } @{$c->{fields}->{eprint}} )
{
	push @{$c->{fields}->{eprint}},
		{
			name => 'projects',
			type => 'dataobjref',
			multiple => 1,
			datasetid => 'project',
			fields => [
				{ sub_name=>"title", type=>"text", },
			],
		};
}

$c->{search}->{project} = 
{
};


$c->{get_projects_for_contributor} = sub {
	my ( $repo, $user, ) = @_;

	my $ds = $repo->dataset( "project" );

	my $list = $ds->search(
		filters => [
                 	{ meta_fields => [ 'contributors_alex_user_id' ], value => $user->get_id(), match => 'EQ' }
		],
		custom_order => "-datestamp" );

	return $list;
}; 

$c->add_dataset_trigger( "project", EPrints::Const::EP_TRIGGER_BEFORE_COMMIT, sub { 
        my( %params ) = @_; 

        my $repo = $params{repository}; 
        my $project = $params{dataobj}; 

	#update the divisions
	my $alex_ids = {};
	my $unique_div_vals = {};
	my $contributors = $project->get_value( "contributors" );
	foreach my $contributor ( @$contributors )
	{
		my $id = $contributor->{ "alex_user_id" };
		$alex_ids->{$id}++ if $id;
	}
	my $user_ds = $project->repository->dataset( "user" );
	foreach my $uid ( keys %$alex_ids )
	{
		my $user = $user_ds->dataobj( $uid );
		next unless $user;
		my $user_vals  = $user->get_value( "divisions" );
		foreach my $division ( @$user_vals ) 
		{
			$unique_div_vals->{$division}++;
		}
	} 
	
	my @new_divs = keys %$unique_div_vals;
	$project->set_value( "divisions", \@new_divs );

} );




{
no warnings;

package Cerif::Project;

@Cerif::Project::ISA = qw( EPrints::DataObj );

sub get_dataset_id { "project" }

sub get_url { shift->uri }

sub commit
{
	my( $self, $force ) = @_;
	if( !$self->is_set( "datestamp" ) ) 
	{
		$self->set_value( "datestamp", EPrints::Time::get_iso_timestamp() );
	}
	return $self->SUPER::commit( $force );
}

sub has_owner
{
	my( $self, $possible_owner ) = @_;

	my $fn = $self->{session}->get_repository->get_conf( "does_user_own_project" );

	if( !defined $fn )
	{
		return 0;
	}
	#my $is_owner = &$fn( $self->{session}, $possible_owner, $self );
#print STDERR "project::has_owner return [".$is_owner."] item[".$self->get_id."] owner[".$possible_owner->get_id."]\n";
	return &$fn( $self->{session}, $possible_owner, $self );

# called from the project citation provides an xhtml fragment.
# contributors with an alex_user_id are rendered as links to their profile
sub render_contributors_with_link
{
	my( $self, $type_name, ) = @_;

	my $type = $type_name->[0] || "contributors";
	my $repo = $self->{session}; 
	my $frag = $repo->make_doc_fragment;
	# clone the array so that we can manipulate the data without fear of the
	my $contributors =  $self->get_value( $type );
	if ( $contributors )
	{
		my $need_join = 0;
		my $index = 0;
		my $limit = scalar @$contributors;
		foreach my $contrib ( @$contributors )
		{
			if ( $index )
			{
				if ( $index == ( $limit - 1 ) )
				{
					$frag->appendChild( $repo->html_phrase( "lib/metafield:join_name.last" ) );
				}
				else
				{
			 		$frag->appendChild( $repo->html_phrase( "lib/metafield:join_name" ) );
				}
			}
			my $alex_user_id =  $contrib->{alex_user_id};
			if ( $alex_user_id )
			{
        			my $repo_url = $repo->config( "base_url" );
				my $profile_url = $repo->make_element( "a", href => "$repo_url/persons/".$alex_user_id );
				$profile_url->appendChild( $repo->render_name( $contrib->{name} ) );
				$frag->appendChild( $profile_url );
			}
			else
			{
				$frag->appendChild( $repo->render_name( $contrib->{name} ) );
			}
			if ( $contrib->{type} )
			{
				my $type_str = $repo->phrase( "project_contributor_type_typename_".$contrib->{type} );
				$frag->appendChild( $repo->make_text( " (".$type_str.")" ) ); 
			}
			$index++;
		}
	}

	return $frag;
}



}



#package Cerif::OrganisationUnit;
#
#@Cerif::OrganisationUnit::ISA = qw( EPrints::DataObj );
#
#sub get_dataset_id { "org_unit" }
#
#sub get_url { shift->uri }
#
}
