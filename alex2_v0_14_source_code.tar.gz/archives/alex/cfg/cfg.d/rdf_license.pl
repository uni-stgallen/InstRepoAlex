
# Licence to be inserted into all RDF data.

# See: 
#   http://wiki.eprints.org/w/EPrints_RDF 
# for more information.

# We suggest using Open Data Commons licenses as these are more sutiable for 
# data than normal Creative Commons. Follow the license URLs for more 
# information.

# $c->{rdf}->{license} = "http://www.opendatacommons.org/licenses/by/";
# OR
# $c->{rdf}->{license} = "http://www.opendatacommons.org/licenses/odbl/";

# $c->{rdf}->{attributionName} = ".....";
# $c->{rdf}->{attributionURL} = ".....";

# More detailed repository policy information is lifted from oai.pl

