
$c->{render_creators_input} = sub {
        my( $self, $session, $value, $dataset, $staff, $hidden_fields, $obj, $basename ) = @_;
        #
        # Code based on MetaField::render_input_field_actual
        #
	my $elements = $session->call( "get_creators_input_elements", $self, $session, $value, $staff, $obj, $basename );

	my $frag = $session->make_doc_fragment;

	my $table = $session->make_element( "table", border=>0, cellpadding=>0, cellspacing=>0, class=>"ep_form_input_grid" );
	$frag->appendChild ($table);

	my $col_titles = [];
	my $f = $self->get_property( "fields_cache" );
	foreach my $field ( @{$f} )
	{
		my $fieldname = $field->get_name;
		# Uncomment the next line to remove the alex user id column name
		#next if $fieldname eq "creators_alex_user_id";
		my $sub_r = $field->get_input_col_titles( $session, $staff );

		if( !defined $sub_r )
		{
			$sub_r = [ $field->render_name( $session ) ];
		}

		push @$col_titles, @{$sub_r};
	}
	
	if( defined $col_titles )
	{
		my $tr = $session->make_element( "tr" );
		my $th;
		my $x = 0;
		if( $self->get_property( "multiple" ) && $self->{input_ordered})
		{
			$th = $session->make_element( "th", class=>"empty_heading", id=>$basename."_th_".$x++ );
			$tr->appendChild( $th );
			$th = $session->make_element( "th", class=>"empty_heading", id=>$basename."_th_".$x++ );
			$tr->appendChild( $th );
		}

		if( !defined $col_titles )
		{
			$th = $session->make_element( "th", class=>"empty_heading", id=>$basename."_th_".$x++ );
			$tr->appendChild( $th );
		}	
		else
		{
			foreach my $col_title ( @{$col_titles} )
			{
				$th = $session->make_element( "th", id=>$basename."_th_".$x++ );
				$th->appendChild( $col_title );
				$tr->appendChild( $th );
			}
		}
		$table->appendChild( $tr );
	}

	my $y = 0;
	foreach my $row ( @{$elements} )
	{
		my $x = 0;
		my $tr = $session->make_element( "tr" );
		foreach my $item ( @{$row} )
		{
			my %opts = ( valign=>"top", id=>$basename."_cell_".$x++."_".$y );
			foreach my $prop ( keys %{$item} )
			{
				next if( $prop eq "el" );
				$opts{$prop} = $item->{$prop};
			}	
			my $td = $session->make_element( "td", %opts );
			if( defined $item->{el} )
			{
				$td->appendChild( $item->{el} );
			}
			$tr->appendChild( $td );
		}
		$table->appendChild( $tr );
		$y++;
	}

	my $extra_params = URI->new( 'http:' );
	$extra_params->query( $self->{input_lookup_params} );
	my @params = (
		$extra_params->query_form,
		field => $self->name
	);
	if( defined $obj )
	{
		push @params, dataobj => $obj->id;
	}
	if( defined $self->{dataset} )
	{
		push @params, dataset => $self->{dataset}->id;
	}
	$extra_params->query_form( @params );
	$extra_params = "&" . $extra_params->query;

	my $componentid = substr($basename, 0, length($basename)-length($self->{name})-1);
	my $url = EPrints::Utils::js_string( $self->{input_lookup_url} );
	my $params = EPrints::Utils::js_string( $extra_params );
	$frag->appendChild( $session->make_javascript( <<EOJ ) );
new Metafield ('$componentid', '$self->{name}', {
	input_lookup_url: $url,
	input_lookup_params: $params
});
EOJ

	return $frag;
};

$c->{get_creators_input_elements} = sub {
	my( $self, $session, $value, $staff, $obj, $basename ) = @_;	

	my $n = length( $basename) - length( $self->{name}) - 1;
	my $componentid = substr( $basename, 0, $n );

	unless( $self->get_property( "multiple" ) )
	{
		return $self->get_input_elements_single( 
				$session, 
				$value,
				$basename,
				$staff,
				$obj );
	}

	# multiple field...

	my $boxcount = $session->param( $basename."_spaces" );
	if( !defined $boxcount )
	{
		$boxcount = $self->{input_boxes};
	}
	$value = [] if( !defined $value );
	my $cnt = scalar @{$value};
	#cjg hack hack hack
	if( $boxcount<=$cnt )
	{
		if( $self->{name} eq "editperms" )
		{
			$boxcount = $cnt;
		}	
		else
		{
			$boxcount = $cnt+$self->{input_add_boxes};
		}
	}
	my $ibutton = $session->get_internal_button;
	if( $ibutton eq $basename."_morespaces" ) 
	{
		$boxcount += $self->{input_add_boxes};
	}

	my $imagesurl = $session->config( "rel_path" )."/style/images";
	
	my $rows = [];
	for( my $i=1 ; $i<=$boxcount ; ++$i )
	{
		my $alex_user_id = $value->[$i-1]->{"alex_user_id"};
		my $section = $self->get_input_elements_single( 
				$session, 
				$value->[$i-1], 
				$basename."_".$i,
				$staff,
				$obj );
	
		# the following code will remove the alex user id input
		# this will however mean that that field will be cleared
		# and will not be set by the autocomplete process.
		#
		# might work with a hidden field?
		#
		#my $section_full = $self->get_input_elements_single( 
		#		$session, 
		#		$value->[$i-1], 
		#		$basename."_".$i,
		#		$staff,
		#		$obj );
		#my $el_name = $basename."_".$i."_alex_user_id";
		#my $section = [];
		#foreach my $sect ( @$section_full )
		#{
		#	my $els = [];
		#	foreach my $el ( @$sect )
		#	{ 
		#		my $this_el = $el->{el}->toString();
		#		if ( $this_el && $this_el !~ /$el_name/ )
		#		{
		#			push @$els, $el;
		#		}
		#	}
		#	push @$section, $els;
		#} 
		my $first = 1;
		for my $n (0..(scalar @{$section})-1)
		{
			my $row =  [  @{$section->[$n]} ];
			my $col0 = {};
			my $col1 = {};
			my $lastcol = {};
			if( $n == 0 && $self->{input_ordered})
			{
				if ( $alex_user_id && $alex_user_id > 0 )
				{
					my $peterli = $session->make_element(
						"img",
						src=> "$imagesurl/hsg_peterli.png",
						alt=>"HSG Author",
						title=>"HSG Author",
					);
	

					$col0 = { el=>$peterli, class=>"ep_form_input_grid_pos" };
				}
				$col1 = { el=>$session->make_text( $i.". " ), class=>"ep_form_input_grid_pos" };
				my $arrows = $session->make_doc_fragment;
				$arrows->appendChild( $session->make_element(
					"input",
					type=>"image",
					src=> "$imagesurl/multi_down.png",
					alt=>"down",
					title=>"move down",
#					title=> ???->html_phrase( "move_down" ),
               				name=>"_internal_".$basename."_down_$i",
					class => "epjs_ajax",
					value=>"1" ));
	
				$arrows->appendChild( $session->make_text( " " ) );
				$arrows->appendChild( $session->make_element(
					"input",
					type=>"image",
					src=> "$imagesurl/x_button.png",
					alt=>"remove",
					title=>"Remove",
#					title=> ???->html_phrase( "remove" ),
               				name=>"_internal_".$basename."_remove_$i",
					class => "epjs_ajax",
					value=>"1" ));
				if( $i > 1 )
				{
					$arrows->appendChild( $session->make_text( " " ) );
					$arrows->appendChild( $session->make_element(
						"input",
						type=>"image",
						alt=>"up",
						title=>"move up",
#						title=> ???->html_phrase( "move_up" ),
						src=> "$imagesurl/multi_up.png",
                		name=>"_internal_".$basename."_up_$i",
						class => "epjs_ajax",
						value=>"1" ));
				}
				$lastcol = { el=>$arrows, valign=>"middle", class=>"ep_form_input_grid_arrows" };
				$row =  [ $col0, $col1, @{$section->[$n]}, $lastcol ];
			}
			push @{$rows}, $row;
		}
	}

	my $more = $session->make_doc_fragment;
	$more->appendChild( $session->render_hidden_field(
					$basename."_spaces",
					$boxcount ) 
	);

	if ($self->{input_add_boxes} > 0)
	{
		$more->appendChild( $session->render_button(
			name => "_internal_".$basename."_morespaces",
			value => $session->phrase( "lib/metafield:more_spaces" ),
			class => "ep_form_internal_button epjs_ajax"
		) );
	}

	my @row = ();
	push @row, {} if( $self->{input_ordered} );
	push @row, {el=>$more,colspan=>3,class=>"ep_form_input_grid_wide"};
	push @{$rows}, \@row;

	return $rows;
};



#Extend the EPrint DataObj to add a function that can be called via epc script

{
package EPrints::DataObj::EPrint;

use strict;


sub is_contribution_required
{
	my( $self, $contribution, $types ) = @_;

	foreach my $type ( @$types )
	{
		return 1 if $type eq "ALL";
		return 1 if $type eq $contribution;
	}
	return 0;
}
	
# called from the citation provides an xhtml fragment.
sub render_contributors_for_type
{
	my( $self, $type_name, $limit_param, $show_type ) = @_;

	my $type = $type_name->[0] || "ALL";
	my @type_list = split( ",", $type );
	my $limit = $limit_param->[0] || 0;
	my $repo = $self->{session}; 
	my $frag = $repo->make_doc_fragment;
	# clone the array so that we can manipulate the data without fear of the
	# item being commited with changes made through the reference.
	my $contributors =  EPrints::Utils::clone( $self->get_value( "contributors" ) );
	if ( $contributors )
	{
		# Filter by contribution type
		my $filtered_contributors = [];
		foreach my $contrib ( @$contributors )
		{
			push @$filtered_contributors, $contrib 
				if $self->is_contribution_required( $contrib->{type}, \@type_list );
		}


		# Filter by limit
		$limit = scalar @$filtered_contributors unless $limit;

		if ( 0 == $limit )
		{
			$frag->appendChild( $repo->html_phrase( "render_contributors_for_type:no_contributors" ) );
		}
		elsif ( $limit < scalar @$filtered_contributors )
		{
			my $need_join = 0;
			my @new_contrib_list = splice( @$filtered_contributors, 0, $limit );
			foreach my $contrib ( @new_contrib_list )
			{
		 		$frag->appendChild( $repo->html_phrase( "lib/metafield:join_name" ) ) if $need_join;
				$frag->appendChild( $repo->render_name( $contrib->{disp_name} ) );
				$frag->appendChild( $repo->html_phrase( "render_contributors_for_type:contribution_type:".$contrib->{type} ) ) if $show_type;
				$need_join++;
			}
			$frag->appendChild( $repo->html_phrase( "lib/metafield:join_name" ) ) if $need_join;
			$frag->appendChild( $repo->html_phrase( "render_contributors_for_type:limit_contributors" ) );
		}
		else
		{
			my $index = 0;
			foreach my $contrib ( @$filtered_contributors )
			{
				if ( $index )
				{
					if ( $index == ( $limit - 1 ) )
					{
						$frag->appendChild( $repo->html_phrase( "lib/metafield:join_name.last" ) );
					}
					else
					{
				 		$frag->appendChild( $repo->html_phrase( "lib/metafield:join_name" ) );
					}
				}
				$frag->appendChild( $repo->render_name( $contrib->{disp_name} ) );
				$frag->appendChild( $repo->html_phrase( "render_contributors_for_type:contribution_type:".$contrib->{type} ) ) if $show_type;

				$index++;
			}
		}

	}
	else
	{
		$frag->appendChild( $repo->html_phrase( "render_contributors_for_type:no_contributors" ) );
	}

	return $frag;
}

# called from the citation provides an xhtml fragment.
# contributors with an alex_user_id are rendered as links to their profile
sub render_contributors_with_link
{
	my( $self, $type_name, ) = @_;

	my $type = $type_name->[0] || "creators";
	my $repo = $self->{session}; 
	my $frag = $repo->make_doc_fragment;
	# clone the array so that we can manipulate the data without fear of the
	my $contributors =  $self->get_value( $type );
	if ( $contributors )
	{
		my $need_join = 0;
		my $index = 0;
		my $limit = scalar @$contributors;
		foreach my $contrib ( @$contributors )
		{
			if ( $index )
			{
				if ( $index == ( $limit - 1 ) )
				{
					$frag->appendChild( $repo->html_phrase( "lib/metafield:join_name.last" ) );
				}
				else
				{
			 		$frag->appendChild( $repo->html_phrase( "lib/metafield:join_name" ) );
				}
			}
			my $alex_user_id =  $contrib->{alex_user_id};
			if ( $alex_user_id )
			{
        			my $repo_url = $repo->config( "base_url" );
				my $profile_url = $repo->make_element( "a", href => "$repo_url/persons/".$alex_user_id );
				$profile_url->appendChild( $repo->render_name( $contrib->{name} ) );
				$frag->appendChild( $profile_url );
			}
			else
			{
				$frag->appendChild( $repo->render_name( $contrib->{name} ) );
			}
			$index++;
		}
	}

	return $frag;
}

# renders the uri as an alex uri 
sub render_alex_uri
{
	my( $self ) = @_;

	my $repo = $self->{session}; 
	my $id =  $self->get_id( );
        my $repo_url = $repo->config( "base_url" );
	my $alex_url = $repo->make_element( "a", href => $repo_url."/publications/".$id );
	$alex_url->appendChild( $repo->make_text( $repo_url."/publications/".$id ) );
	return $alex_url;
}

# renders the doi as a simple string
sub render_doi_in_pdf
{
	my( $self ) = @_;

	my $repo = $self->{session}; 
	my $doi =  $self->get_value( "doi" );
	my $str = $repo->make_text( "DOI: ".$doi );
	return $str;
}




}

{
# Package for extensions to EPrints::Script::Compiled
package EPrints::Script::Compiled;

use strict;

sub run_render_contributors_with_link
{
        my( $self, $state, $eprint, $type ) = @_;
        if( ! $eprint->[0]->isa( "EPrints::DataObj::EPrint" ) && ! $eprint->[0]->isa( "Cerif::Project" ) )
        {
                $self->runtime_error( "Can only call render_contributors_with_link() on eprint or project objects not ".
                        ref($eprint->[0]) );
        }

        return [ $eprint->[0]->render_contributors_with_link( $type ), "XHTML"  ];
}


sub run_render_contributors_for_type
{
        my( $self, $state, $eprint, $type, $limit, $show_type ) = @_;
        if( ! $eprint->[0]->isa( "EPrints::DataObj::EPrint" ) )
        {
                $self->runtime_error( "Can only call render_contributors_for_type() on eprint objects not ".
                        ref($eprint->[0]) );
        }

        return [ $eprint->[0]->render_contributors_for_type( $type, $limit, $show_type ), "XHTML"  ];
}

sub run_render_alex_uri
{
        my( $self, $state, $eprint, ) = @_;
        if( ! $eprint->[0]->isa( "EPrints::DataObj::EPrint" ) )
        {
                $self->runtime_error( "Can only call render_alex_uri() on eprint objects not ".
                        ref($eprint->[0]) );
        }

        return [ $eprint->[0]->render_alex_uri( ), "XHTML"  ];
}

sub run_render_doi_in_pdf
{
        my( $self, $state, $eprint, ) = @_;
        if( ! $eprint->[0]->isa( "EPrints::DataObj::EPrint" ) )
        {
                $self->runtime_error( "Can only call render_doi_in_pdf() on eprint objects not ".
                        ref($eprint->[0]) );
        }

        return [ $eprint->[0]->render_doi_in_pdf( ), "XHTML"  ];
}



}



