
$c->{render_markup} = sub {
	my( $repo, $field, $value, $object ) = @_;

	my $frag = $repo->make_doc_fragment;
        return $frag unless $value && $field && $object;

	my $id = $field->name."_".$object->get_id."_markup";
	my $span = $frag->appendChild( $repo->make_element( "span", id=>$id, ) ); 
	$span->appendChild( $repo->make_javascript( <<EOJ ) );
   document.getElementById("$id").innerHTML = '$value';
EOJ
	return $frag;
}
