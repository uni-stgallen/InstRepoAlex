# IRStats2 configuration file for HSG



# Show the link to the reports:
# currently commented ou as the link to the reports is a url on the left menu
$c->{plugins}->{"Screen::IRStats2::ReportHSG"}->{appears}->{key_tools} = undef;


