
######################################################################
#
# Dynamic Template
#
# If you use a dynamic template then this function is called every
# time a page is served to generate dynamic parts of it.
# 
# The dynamic template feature may be disabled to reduce server load.
#
# When enabling/disabling it, run 
# generate_apacheconf
# generate_static
# generate_views
# generate_abstracts
#
######################################################################

$c->{dynamic_template}->{enable} = 1;

# This method is called for every page to add/refine any parts that are
# specified in the template as <epc:pin ref="name" />

$c->{dynamic_template}->{function} = sub {
        my( $repository, $parts ) = @_;

        my $frag = $repository->make_element( "div", class => "nav_contact ep_alex_login_status" );

        if( defined( $repository->current_user ) )
        {
		my $user = $repository->current_user;
                my $link = $frag->appendChild( $repository->plugin( "Screen::Logout" )->render_action_link() );
		$link->setAttribute( "style", "border-right: 0.2em solid #aaa; padding-right: 0.7em; margin-right: 0.7em;" );
                my $name = $frag->appendChild( $repository->render_name( $user->get_value( "name" ), 1 ) );
		$name->setAttribute( "style", "border-right: 0.2em solid #aaa; padding-right: 0.7em; margin-right: 0.7em;" );
        }
	else
	{
        	my $link = $frag->appendChild( $repository->plugin( "Screen::HSG_Alex_Login" )->render_action_link() );
		$link->setAttribute( "style", "border-right: 0.2em solid #aaa; padding-right: 0.7em; margin-right: 0.7em;" );
	}

        $parts->{alex_login_status} = $frag;
       
        $parts->{alex_login_actions_status} = EPrints::ScreenProcessor->new(
                session => $repository
        )->render_toolbar;;

        #$parts->{alex_project_link} = $repository->plugin( "Screen::Project_Link" )->render_action_link();

	# form the shariff url

	my $mail_to = "";
        my $shariff = $repository->make_element( "div", class => "shariff", );
	my $path = $repository->config( "base_url" );
	my $request = $repository->get_request;
	if ( $request )
	{
		my $req_uri = $request->uri;
		my $lang_id = $repository->get_langid;
        	$shariff = $repository->make_element( "div", class => "shariff", id=>"socialmedia", 
			#style => "position:absolute; right: 0px; text-align:right;bottom: 45px;width: 400px; ", 
			style => "float:right;width: 700px; ", 

			'data-services' => "[\"twitter\", \"facebook\", \"googleplus\", \"linkedin\", \"mail\", \"info\" ]",
			'data-backend-url' =>"/cgi/shariff", 
			'data-mail-url' => 'mailto:'.$mail_to,
			'data-url' => $path.$req_uri,
			#'data-theme' => 'white',
			'data-lang' => $lang_id,
			'data-info-url' => $path."/about.html#privacy", );

	}
        $parts->{shariff} = $shariff;
};






# To support backwards-compatibility the new-style key tools plugins are
# included here
#$c->{plugins}->{"Screen::Login"}->{appears}->{key_tools} = 100;
#$c->{plugins}->{"Screen::Register"}->{actions}->{register}->{appears}->{key_tools} = 150;
#$c->{plugins}->{"Screen::Logout"}->{appears}->{key_tools} = 10000;
#$c->{plugins}->{"Screen::Admin::Config::Edit::XPage"}->{actions}->{edit}->{appears}->{key_tools} = 1250;
#$c->{plugins}->{"Screen::Home"}->{appears}->{key_tools} = 90;
$c->{plugins}->{"Screen::Admin::Phrases"}->{actions}->{edit}->{appears}->{key_tools} = 1350;
#$c->{plugins}->{"Screen::OtherTools"}->{appears}->{key_tools} = 20000;
