#
# set the global variable for the view max items for production  
#

$c->{browse_views_max_items} = 2500 if $c->{host} eq 'ux-alex-prod.unisg.ch';

