
push @{$c->{public_roles}}, qw(
    +combined/export
    +combined/search
    +combined/view
);



$c->{datasets}->{combined} = {
	class => 'Alex::Combined',
	sqlname => 'combined',
	index => 0,
	import => 0,
	search => {
		simple => {
			search_fields => [{
				id => "q",
				meta_fields => [qw(
					title
				)],
			}],
			order_methods => { },
			default_order => "byrelevance",
			show_zero_results => 1,
			citation => "picresult",
		},
	},
};

$c->{fields}->{combined} = [] if !defined $c->{fields}->{combined};
unshift @{$c->{fields}->{combined}}, (
	{
		name => 'combinedid',
		type => 'counter',
		sql_counter => 'combinedid',
	},
	{
		name => 'title',
		type => 'text',
	},
);


{
no warnings;

package Alex::Combined;

@Alex::Combined::ISA = qw( EPrints::DataObj );

sub get_dataset_id { "combined" }

}
