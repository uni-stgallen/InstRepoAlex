
$c->{defaultlanguage} = 'en';

$c->{languages} = [ 'de', 'en' ];

