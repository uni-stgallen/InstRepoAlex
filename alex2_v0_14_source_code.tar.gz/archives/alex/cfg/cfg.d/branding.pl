
# Replace this with your logo, or just replace the file in
# cfg/static/images and run generate_static

$c->{site_logo} = "/images/sitelogo.png";

# A theme overrides some of the styles and images used by
# eprints. A theme must exist as a directory in 
# /opt/eprints3/lib/themes

# $c->{theme} = "green";
