#
# Settings for the Sherpa Romeo API
#

$c->{sherpa_romeo_Key} = 'XcATKLRSePE';
$c->{sherpa_romeo_url} = 'http://www.sherpa.ac.uk/romeo/api29.php';


$c->{get_sherpa_data} = sub
{
	my( $repo, $item ) = @_;

	my $phrase_root = "Plugin/InputForm/Component/Field/Modal/SherpaRomeo:";
	my $messages = [];
	my $data = {};
	my $current_user = $repo->current_user;

	my $sherpa_url = $repo->config( "sherpa_romeo_url" );
	my $access_key = $repo->config( "sherpa_romeo_Key" );
	my $current_lang = $repo->get_lang->get_id;
	my $params = {};
	$params->{"ak"} = $access_key if $access_key;
	$params->{"la"} = $current_lang if $current_lang;

	if ( $item->is_set( "issn" ) )
	{
		$params->{"issn"} = $item->get_value( "issn" );
		#push @$messages, { type=>"message", content=>$repo->html_phrase( $phrase_root."search_by_issn") };
	}
	elsif ( $item->is_set( "publication" ) )
	{
		$params->{"jtitle"} = $item->get_value( "publication" );
		#$params->{"qtype"} = "exact";
		$params->{"qtype"} = "starts";
		#push @$messages, { type=>"message", content=>$repo->html_phrase( $phrase_root."search_by_title") };
	}
	elsif ( $item->is_set( "publisher" ) )
	{
		$params->{"pub"} = $item->get_value( "publisher" );
		$params->{"qtype"} = "exact";
		#push @$messages, { type=>"message", content=>$repo->html_phrase( $phrase_root."search_by_pub") };
	}
	else
	{
		push @$messages, { type=>"warning", content=>$repo->html_phrase($phrase_root."no_search_term") };
	}

	my $url = URI->new( $sherpa_url );
	$url->query_form( %$params );

	my $dom_doc;
	eval {
		$dom_doc = EPrints::XML::parse_url( $url );
	};
#print STDERR "got data:\n ".$dom_doc->toString."\n";
	my $dom_top = $dom_doc->getDocumentElement;

	my $apicontrol = EPrints::Utils::tree_to_utf8( ($dom_top->getElementsByTagName( "apicontrol" ))[0] );
	my $numhits = EPrints::Utils::tree_to_utf8( ($dom_top->getElementsByTagName( "numhits" ))[0] );
	my $message = EPrints::Utils::tree_to_utf8( ($dom_top->getElementsByTagName( "message" ))[0] );
	my $outcome = EPrints::Utils::tree_to_utf8( ($dom_top->getElementsByTagName( "outcome" ))[0] );
	my @journals = $dom_top->getElementsByTagName( "journal" );

	$data->{source} = $apicontrol;
	$data->{numhits} = $numhits;
	$data->{message} = $message;
	$data->{outcome} = $outcome;
	my $journal_limit = 3;
	my $journal_index = 0;
	foreach my $journal ( @journals )
	{
		$journal_index++;
		my $title = EPrints::Utils::tree_to_utf8( ($journal->getElementsByTagName( "jtitle" ))[0] );
		my $issn = EPrints::Utils::tree_to_utf8( ($journal->getElementsByTagName( "issn" ))[0] );
		my $publisher = EPrints::Utils::tree_to_utf8( ($journal->getElementsByTagName( "romeopub" ))[0] );
		$data->{journals}->{$journal_index}->{title} = $title;
		$data->{journals}->{$journal_index}->{issn} = $issn;
		$data->{journals}->{$journal_index}->{publisher} = $publisher;
		last if $journal_index > $journal_limit;
	}

use utf8;	

	my $colour_code = {
		green => "green",
		blue => "blue",
		yellow => "yellow",
		white => "white",
		grün => "green",
		blau => "blue",
		gelb => "yellow",
		weiß => "white",
		vert => "green",
		bleu => "blue",
		jaune => "yellow",
		blanc => "white",
	};	

	if ( $numhits && 1 == $numhits && $outcome =~ /singleJournal|publisherFound/ )
	{
		foreach my $print_type (qw\ pre post pdf \)
		{
			my $tag = $print_type."prints";
			$tag = "pdfversion" if $print_type eq "pdf";
			my $tag_prints = ($dom_top->getElementsByTagName( $tag ))[0];
			my $tag_archiving_xml = ($tag_prints->getElementsByTagName( $print_type."archiving" ))[0];
			my $tag_restrictions_tag = ($tag_prints->getElementsByTagName( $print_type."restrictions" ))[0];
			my @tag_restrictions = $tag_restrictions_tag->getElementsByTagName( $print_type."restriction" );

			my $tag_archiving = EPrints::Utils::tree_to_utf8( $tag_archiving_xml );
			$data->{"sherpa_romeo_".$print_type} = $tag_archiving;
			my $item_restrictions = [];
			foreach my $restriction ( @tag_restrictions )
			{
				push @$item_restrictions, EPrints::Utils::tree_to_utf8( $restriction );
			}
			$data->{"sherpa_romeo_".$print_type."_restrictions"} = $item_restrictions;
		}

		my $conditions_tag = ($dom_top->getElementsByTagName( "conditions" ))[0];
		my @conditions = $conditions_tag->getElementsByTagName( "condition" );
		my $item_conditions = [];
		foreach my $condition ( @conditions )
		{
			push @$item_conditions, EPrints::Utils::tree_to_utf8( $condition );
		}
		$data->{"sherpa_romeo_conditions"} = $item_conditions;

		my $colour = EPrints::Utils::tree_to_utf8(($dom_top->getElementsByTagName( "romeocolour" ))[0]);
		# the colour should be a code not a translated name of a colour!!!
		
		$data->{"sherpa_romeo_colour"} =  $colour_code->{$colour};
	}
	else
	{
		$outcome = "Not Specified" if ! EPrints::Utils::is_set( $outcome );
		$message = "No further details" if ! EPrints::Utils::is_set( $message );
		$numhits = 0 if ! EPrints::Utils::is_set( $numhits );

		my $html_message = $repo->html_phrase( $phrase_root."outcome", 
					hits => $repo->make_text( $numhits ), 
					outcome => $repo->make_text( $outcome ), 
					message => $repo->make_text( $message ) );
					
		my $message_type = "message";
		$message_type = "warning" if $outcome eq "failed";
		$message_type = "warning" if $outcome eq "notFound";

		push @$messages, { type=>$message_type, content=>$html_message };
	}
	$data->{messages} = $messages;
	return $data;
};

$c->{render_sherpa_policy} = sub
{
	my ( $repo, $data, $item ) = @_;

	my $phrase_root = "Plugin/InputForm/Component/Field/Modal/SherpaRomeo:";
	my $source_phrase = $repo->html_phrase( $phrase_root."data_source_".$data->{source} );
	my $colour_phrase = $repo->html_phrase( $phrase_root."unknown_colour_journal" );
	my $print_phrase = {}; 
	$print_phrase->{"pre"} = $repo->make_text( "" );
	$print_phrase->{"post"} = $repo->make_text( "" );
	$print_phrase->{"pdf"} = $repo->make_text( "" );
	my $restriction_phrase = {}; 
	$restriction_phrase->{"pre"} = $repo->make_text( "" );
	$restriction_phrase->{"post"} = $repo->make_text( "" );
	$restriction_phrase->{"pdf"} = $repo->make_text( "" );
	my $conditions_phrase = $repo->make_text( "" );
	my $summary_phrase = $repo->make_text( "" );

	if ( $data->{sherpa_romeo_colour} )
	{
		$colour_phrase = $repo->html_phrase( $phrase_root.$data->{sherpa_romeo_colour} ."_".$data->{source} );
		$summary_phrase = $repo->html_phrase( $phrase_root."summary" );
	}

	foreach my $print_type (qw\ pre post pdf \)
	{
		if ( $data->{"sherpa_romeo_".$print_type} )
		{
			my $statement = $data->{"sherpa_romeo_".$print_type};
			$print_phrase->{$print_type} = $repo->html_phrase( $phrase_root.$print_type."_".$statement );
		}

		if ( $data->{"sherpa_romeo_".$print_type."_restrictions"} )
		{
			my $restrictions = $data->{"sherpa_romeo_".$print_type."_restrictions"};
			my $list = $repo->make_element( "ul" );
			foreach my $restriction ( @$restrictions )
			{
				my $li = $list->appendChild( $repo->make_element( "li" ) ); 
				$li->appendChild( $repo->make_text( $restriction ) );
			}
			$restriction_phrase->{$print_type} = $repo->html_phrase( $phrase_root."restrictions", 
					title=>$repo->make_text("Restrictions"), 
					list=> $list );
		}
	}

	if ( $data->{sherpa_romeo_conditions} )
	{
		my $conditions = $data->{sherpa_romeo_conditions};
		my $list = $repo->make_element( "ul" );
		foreach my $condition ( @$conditions )
		{
			my $li = $list->appendChild( $repo->make_element( "li" ) ); 
			$li->appendChild( $repo->make_text( $condition ) );
		}
		$conditions_phrase = $repo->html_phrase( $phrase_root."restrictions", 
					title=>$repo->make_text( "Conditions" ), 
					list=> $list );
	}

	my $pub_warning = $repo->html_phrase( $phrase_root."warning_".$data->{source} );
	my $jtitle = $item->value("publication");
	my $issn = $item->value("issn");
	my $pub = $item->value("publisher");

	my $jphrase = $repo->html_phrase( $phrase_root."journal_no_match", 
					sj=>$repo->make_text( $data->{journals}->{1}->{title} ),
					ij=>$repo->make_text( $jtitle ) );
	if ( $jtitle && $jtitle eq $data->{journals}->{1}->{title} )
	{
		$jphrase = $repo->html_phrase( $phrase_root."journal_match", 
					jtitle=>$repo->make_text( $data->{journals}->{1}->{title} ) );
	}


	my $issn_phrase = $repo->html_phrase( $phrase_root."issn_no_match", 
                                        sissn=>$repo->make_text( $data->{journals}->{1}->{issn} ),
					iissn=>$repo->make_text( $issn ) );
	if ( $issn && $issn eq $data->{journals}->{1}->{issn} )
	{
		$issn_phrase = $repo->html_phrase( $phrase_root."issn_match", 
                                        issn=>$repo->make_text( $data->{journals}->{1}->{issn} ) );
	}
	my $pub_phrase = $repo->html_phrase( $phrase_root."pub_no_match", 
                                        spub=>$repo->make_text( $data->{journals}->{1}->{publisher} ),
					ipub=>$repo->make_text( $pub ) );
	if ( $pub && $pub eq $data->{journals}->{1}->{publisher} )
	{
		$pub_phrase = $repo->html_phrase( $phrase_root."pub_match", 
                                        pub=>$repo->make_text( $data->{journals}->{1}->{publisher} ) );
	}

	my $report = $repo->html_phrase( $phrase_root."sherpa_report",
			pub_warning => $pub_warning,
			source => $source_phrase,
			jtitle => $jphrase,
			issn => $issn_phrase,
			pub => $pub_phrase,
			colour => $colour_phrase,
			pre => $print_phrase->{"pre"},
			pre_restriction => $restriction_phrase->{"pre"},
			post => $print_phrase->{"post"},
			post_restriction => $restriction_phrase->{"post"},
			pdf => $print_phrase->{"pdf"},
			pdf_restriction => $restriction_phrase->{"pdf"},
			conditions => $conditions_phrase,
			summary => $summary_phrase,
	 );
	return $report;
};

$c->{render_sherpa_multiple} = sub
{
	my ( $repo, $data, $item ) = @_;

	my $rows = $repo->make_element( "tbody" );
	my $phrase_root = "Plugin/InputForm/Component/Field/Modal/SherpaRomeo:";

	foreach my $key ( sort keys %{$data->{journals}} )
	{
		$rows->appendChild( $repo->html_phrase( $phrase_root."sherpa_report_multi_row", 
					row =>$repo->make_text( $key ), 
					jval=>$repo->make_text( $data->{journals}->{$key}->{title} ),
					ival=>$repo->make_text( $data->{journals}->{$key}->{issn} ),
					pval=>$repo->make_text( $data->{journals}->{$key}->{publisher} ),
				) );
		
	}
	my $report = $repo->html_phrase( $phrase_root."sherpa_report_multi", rows => $rows );
	return $report;
};



