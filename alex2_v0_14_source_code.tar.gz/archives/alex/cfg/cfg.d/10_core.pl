# This file was created by bin/epadmin
# You can regenerate this file by doing ./bin/epadmin config_core alex
$c->{host} = 'dev-www.alexandria.unisg.ch';
$c->{port} = 80;
$c->{aliases} = [];
$c->{securehost} = 'dev-www.alexandria.unisg.ch';
$c->{secureport} = 443;
$c->{http_root} = undef;
