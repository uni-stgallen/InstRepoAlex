
######################################################################
#
# Latest_tool Configuration
#
#  the latest_tool script is used to output the last "n" items 
#  accepted into the repository
#
######################################################################

$c->{latest_tool_modes} = {
	default => { citation => "result" ,},
	# a mode for articles
	articles => {
		citation => "latest_article_pic",
		filters => [
			{ meta_fields => [ "type" ], value => "article" }
		],
		max => 10
	},
	# a mode for books and book sections
	books => {
		citation => "latest_book_pic",
		filters => [
			{ meta_fields => [ "type" ], value => "book" }
		],
		max => 10
	},
	# a mode for users 
	users => {
		citation => "latest_user",
		filters => [
		],
		max => 10 
	},
	# a mode for users 
	projects => {
		citation => "latest_project",
		filters => [
		],
		max => 10 
	},


};

# Example of a latest_tool mode. This makes a mode=articles option
# which only lists eprints who's type equals "article".
#	
#	articles => {
#		citation => undef,
#		filters => [
#			{ meta_fields => [ "type" ], value => "article" }
#		],
#		max => 20
#	}


