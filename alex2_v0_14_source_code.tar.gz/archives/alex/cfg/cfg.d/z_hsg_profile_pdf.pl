#
# publication list settings
#

# allow anyone to download the user profile/publication list
push @{$c->{public_roles}}, "+user/export";

$c->{profile_pdf_settings} = {

	cache_pdf => 0,
	filename_prefix => "publication_list_",
	filename_inc_name => 1,
	filename_ext => "pdf",
	width => 210,
	height => 297,
	bleed => "5",
	crop => "7.5",
	art => "10",
	logo => "images-unisg-logo-300dpi.png", # needs to be a png format image such as "sitelogo.png",
	watermark_x => 15,
	watermark_y => 35,
	footer_x => 25,
	footer_page_x => 175,
	footer_y => 15,

	header_font_name => "Helvetica-Bold",
	header_font_size => "18",
	header_font_colour => "black",

	title_font_name => "Helvetica-Bold", 
	title_font_size => "14",
	title_font_colour => "#34995f",

	sub_title_font_name => "Helvetica-Bold",
	sub_title_font_size => "10",
	sub_title_font_colour => "black",

	watermark_font_name => "Helvetica-Bold", 
	watermark_font_size => "9",
	watermark_font_colour_1 => "#444444",
	watermark_font_colour_2 => "#34995f",
	watermark_font_colour_3 => "#444444",

	font_name => "Helvetica",
	font_size => "10",
	font_colour => "black",

	footer_font_name => "Helvetica",
	footer_font_size => "10",
	footer_font_colour => "#444444",

	detail_fields => [qw/ org street post_code city phone email /],
	detail_field_offset => 30,

	category => {
		forthcoming	=>	"forthcoming",
		article		=>	"article",
		newspaper	=>	"newspaper",
		book		=>	"book",
		book_section	=>	"book_section",
		book_review	=>	"book_review",
		case_study	=>	"case_study",
		digital_resource => 	"general",
		monograph	=>	"monograph",
		conference_item	=>	"conf",
		thesis		=>	"thesis",
		law_paper	=>	"law_paper",
		presentation	=>	"presentation",
		patent		=>	"general",
		artefact	=>	"general",
		exhibition	=>	"general",
		composition	=>	"general",
		performance	=>	"general",
		image		=>	"general",
		video		=>	"general",
		audio		=>	"general",
		dataset		=>	"general",
		experiment	=>	"general",
		teaching_resource =>	"general",
		other		=>	"general",
	},
	category_order => [qw/ forthcoming article conf_paper book book_section judgment_annotation legal_comment 
			opinion case_study working_paper periodical discussion_paper book_review postdoctoral 
			doctoral general newspaper conf_speech presentation /],
};


$c->{get_publications_for_contributor} = sub {
	my ( $repo, $user, ) = @_;

	my $ds = $repo->dataset( "eprint" );

	my $list1 = $ds->search(
		filters => [
                 	{ meta_fields => [ 'eprint_status' ], value => 'archive', match => 'EQ' },
                 	{ meta_fields => [ 'creators_alex_user_id' ], value => $user->get_id(), match => 'EQ' }
		] );

	my $list2 = $ds->search(
		filters => [
                 	{ meta_fields => [ 'eprint_status' ], value => 'archive', match => 'EQ' },
                 	{ meta_fields => [ 'editors_alex_user_id' ], value => $user->get_id(), match => 'EQ' }
		] );

	my $combined_list = $list1->union($list2);
	return $combined_list->reorder( "-date/title");
}; 

{
# Package for extensions to EPrints::Script::Compiled
package EPrints::Script::Compiled;

use strict;

sub run_get_publication_list_url
{
        my( $self, $state, $user, $field ) = @_;
        my $repo = $user->[0]->repository;
        if( ! $user->[0]->isa( "EPrints::DataObj::User" ) )
        {
                $self->runtime_error( $repo->phrase( "publication_list:runtime_error" ) );
        }
	my $pdf_filename = "publication_list.pdf";
	my $plugin = $repo->plugin( "Export::UserPDF" );
	$pdf_filename = $plugin->form_filename( $user->[0] ) if $plugin;

	my $href = "/cgi/export/user/".$user->[0]->get_id;
	$href .= "/UserPDF/";
	$href .= $pdf_filename;
	my $form = $repo->xml->create_element( "form", method=>"GET", 'accept-charset'=>"utf-8", action=>$href, target=>"_blank" );
	my $btn = $form->appendChild( $repo->xml->create_element( "input", 
			type=> "submit", 
			value=> $repo->phrase( "publication_list:link:title" ), 
			class=> "ep_form_action_button" ) );
        return [ $form, "XHTML"  ];
}

sub run_get_publication_view_url
{
        my( $self, $state, $user, $field ) = @_;
        my $repo = $user->[0]->repository;
        if( ! $user->[0]->isa( "EPrints::DataObj::User" ) )
        {
                $self->runtime_error( $repo->phrase( "publication_view:runtime_error" ) );
        }
	my $userid = $user->[0]->get_id;
        my $path = $repo->config( "base_url" );
        $path .= "/view/pub_alex_user_id/";
        $path .= $userid;
        $path .= ".html";

	my $form = $repo->xml->create_element( "form", method=>"GET", 'accept-charset'=>"utf-8", action=>$path, );
	my $btn = $form->appendChild( $repo->xml->create_element( "input", 
			type=> "submit", 
			value=> $repo->phrase( "publication_view:link:title" ), 
			class=> "ep_form_action_button" ) );
        return [ $form, "XHTML"  ];
}

sub run_get_project_view_url
{
        my( $self, $state, $user, $field ) = @_;
        my $repo = $user->[0]->repository;
        if( ! $user->[0]->isa( "EPrints::DataObj::User" ) )
        {
                $self->runtime_error( $repo->phrase( "project_view:runtime_error" ) );
        }
	my $userid = $user->[0]->get_id;
        my $path = $repo->config( "base_url" );
        $path .= "/view/pro_alex_user_id/";
        $path .= $userid;
        $path .= ".html";

	my $form = $repo->xml->create_element( "form", method=>"GET", 'accept-charset'=>"utf-8", action=>$path, );
	my $btn = $form->appendChild( $repo->xml->create_element( "input", 
			type=> "submit", 
			value=> $repo->phrase( "project_view:link:title" ), 
			class=> "ep_form_action_button" ) );
        return [ $form, "XHTML"  ];
}


}








