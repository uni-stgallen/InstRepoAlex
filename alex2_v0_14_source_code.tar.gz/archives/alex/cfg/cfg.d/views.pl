
# Browse views. allow_null indicates that no value set is 
# a valid result. 
# Multiple fields may be specified for one view, but avoid
# subject or allowing null in this case.
$c->{browse_views} = [
        {
                id => "year",
                menus => [
			{
				fields => [ "date;res=year" ],
				reverse_order => 1,
                		allow_null => 1,
				new_column_at => [10,10],
			}
		],
		citation => "picview",
                order => "creators_name/title",
		variations => [
			"creators_name;first_letter",
			"type",
			"DEFAULT" ],
        },
        {
                id => "subjects",
                menus => [
			{
				fields => [ "subjects" ],
                		hideempty => 1,
			},
		],
		citation => "picview",
                order => "creators_name/title",
                include => 1,
		variations => [
			"date;res=year",
			"creators_name;first_letter",
			"type",
			"DEFAULT",
		],
        },
        {
                id => "divisions",
                menus => [
			{
				fields => [ "divisions" ],
                		hideempty => 1,
			},
			{
				fields => [ "date;res=year" ],
				reverse_order => 1,
                		allow_null => 1,
                		hideempty => 1,
			},
		],
		citation => "picview",
                order => "creators_name/title",
                include => 1,
		variations => [
			"creators_name;first_letter",
			"type",
			"DEFAULT",
		],
        },

#        {
#		id => "creators",
#		allow_null => 0,
#		hideempty => 1,
#		menus => [
#			{
#				fields => [ "creators_name" ],
#				new_column_at => [1, 1],
#				mode => "sections",
#				open_first_section => 1,
#				group_range_function => "EPrints::Update::Views::cluster_ranges_30",
#				grouping_function => "EPrints::Update::Views::group_by_a_to_z",
#			},
#		],
#		order => "-date/title",
#		variations => [
#			"type",
#			"DEFAULT",
#		],
#        },

##
## views for the Publications page
##
 	{
		id => "pub_alex_user_id",
		allow_null => 0,
		hideempty => 1,
		menus => [
			{
				fields => [ "creators_alex_user_id" ],
                                new_column_at => [1,1],
				mode => "sections",
				open_first_section => 1,
			},
		],
		citation => "picview",
		order => "-date/title",
		variations => [
			"type",
			"DEFAULT",
		],
	},
 	{
		id => "pub_creators_name",
		allow_null => 0,
		hideempty => 1,
		menus => [
			{
				fields => [ "creators_name" ],
                                new_column_at => [1,1],
				mode => "sections",
				open_first_section => 1,
				grouping_function => "EPrints::Update::Views::group_by_a_to_z",
			},
		],
		citation => "picview",
		order => "-date/title",
		variations => [
			"type",
			"DEFAULT",
		],
	},
        {
                id => "pub_institute",
                menus => [
                        {
                                fields => [ "divisions" ],
				hideempty => 1,
                        },
			{
				fields => [ "date;res=year" ],
				reverse_order => 1,
                		allow_null => 1,
                		hideempty => 1,
			},
	
                ],
		citation => "picview",
                order => "creators_name/title",
                include => 1,
		variations => [
			"creators_name;first_letter",
			"type",
			"DEFAULT" ],
        },
	{
                id => "pub_year",
                menus => [
			{
				fields => [ "date;res=year" ],
				hideempty => 1,
				reverse_order => 1,
                		allow_null => 1,
				new_column_at => [10,10],
				grouping_function => "EPrints::Update::Views::group_by_a_to_z",
			}
		],
		citation => "picview",
                order => "creators_name/title",
		variations => [
			"creators_name;first_letter",
			"type",
			"DEFAULT" ],
 
	},

##
## views for the Persons page
##
        {
                id => "alex_user_id",
                allow_null => 0,
		hideempty => 1,
		dataset => "public_profile_users",
                menus => [
                        {
                                fields => [ "alex_user_id" ],
                		allow_null => 0,
				hideempty => 1,
                                new_column_at => [1,1],
				mode => "sections",
				open_first_section => 1,
				grouping_function => "EPrints::Update::Views::group_by_a_to_z",
                        }
                ],
                order => "userid",
                include => 1,
		citation => 'view_citation',
		variations => [
			"name;first_letter",
		],
        },

        {
                id => "user_institute",
		dataset => "public_profile_users",
                menus => [
                        {
                                fields => [ "divisions" ],
				hideempty => 1,
                                reverse_order => 1,
                                allow_null => 0,
                                new_column_at => [10,10],
                        }
                ],
                order => "name",
		variations => [
			"name;first_letter",
			"DEFAULT" ],
		citation => 'view_citation',
        },

##
## views for the Projects page
##
	{
		id => "pro_alex_user_id",
		allow_null => 0,
		hideempty => 1,
		dataset => "project",
		menus => [
			{
				fields => [ "contributors_alex_user_id" ],
				#fields => [ "contributors_name" ],
                                new_column_at => [1,1],
				mode => "sections",
				open_first_section => 1,
				grouping_function => "EPrints::Update::Views::group_by_a_to_z",
			},
		],
		citation => "picview",
		order => "-start/title",
		variations => [
			"contributors_name;first_letter",
			"DEFAULT" ],
	},
        {
                id => "project_institute",
		dataset => "project",
                menus => [
                        {
                                fields => [ "divisions" ],
				hideempty => 1,
                                reverse_order => 1,
                                allow_null => 0,
                                new_column_at => [10,10],
                        }
                ],
		citation => "picview",
                order => "title",
		variations => [
			"contributors_name;first_letter",
			"DEFAULT" ],
        },

	{
		id => "project_year",
		dataset => "project",
		allow_null => 0,
		hideempty => 1,
		menus => [
			{
				fields => [ "start;res=year" ],
				reverse_order => 1,
                		allow_null => 1,
				new_column_at => [10,10],
			},
		],
		citation => "picview",
		order => "-start/title",
		variations => [
			"contributors_name;first_letter",
			"DEFAULT" ],
	},
#	{
#		id => "funder",
#		dataset => "eprint",
#		allow_null => 0,
#		hideempty => 1,
#		menus => [
#			{
#				fields => [ "org_units_title" ],
#			},
#		],
#		order => "-datestamp/title",
#	},
        {
                id => "project_funders",
		dataset => "project",
                menus => [
                        {
                                fields => [ "funders" ],
				hideempty => 1,
                                reverse_order => 1,
                                allow_null => 0,
                                new_column_at => [10,10],
                        }
                ],
		citation => "picview",
                order => "title",
		variations => [
			"contributors_name;first_letter",
			"DEFAULT" ],
        },

];

# examples of some other useful views you might want to add
#
# Browse by the ID's of creators & editors (CV Pages). Useful to import the 
# .include part into your main website or their homepage, rather than access
# directly via the eprints website.
#        {
#                id => "person",
#                menus => [
#			{
#				fields => [ "creators_id","editors_id" ],
#                		allow_null => 0,
#			}
#		],
#                order => "-date/title",
#                noindex => 1,
#                nolink => 1,
#                nocount => 0,
#                include => 1,
#        },

# Browse by the names of creators (less reliable than Id's), section the menu 
# by the first 3 characters of the surname, and if there are more than 30 
# names, split the menu up into sub-pages of around 30.
# Show the list of names in 3 columns.
#
#
#	{ 
#		id => "people", 
#		menus => [ 
#			{ 
#				fields => ["creators_name","editors_name"], 
#				allow_null => 0,
#				grouping_function => "EPrints::Update::Views::group_by_3_characters",
#				group_range_function => "EPrints::Update::Views::cluster_ranges_30",
#				mode => "sections",
#				open_first_section => 1,
#				new_column_at => [0,0],
#			} 
#		],
#		order=>"title",
#	},


# Browse by the type of eprint (poster, report etc).
#{ id=>"type", menus=>[ { fields=>"type" } ], order=>"-date" }


