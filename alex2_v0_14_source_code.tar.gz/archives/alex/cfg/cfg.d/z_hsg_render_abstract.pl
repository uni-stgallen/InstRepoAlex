
{
# Package for extensions to EPrints::Script::Compiled
package EPrints::Script::Compiled;

use strict;

my $DEFAULT_ABS_CHARS = 200;

## !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##
## THIS will require modification for multilang operation
##
##
## !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
sub run_render_abstract_first_n_chars
{
        my( $self, $state, $eprint, $field ) = @_;

        if( ! $eprint->[0]->isa( "EPrints::DataObj::EPrint" ) )
        {
                $self->runtime_error( "Can only call render_abstract_first_n_chars() on eprint objects not ".  ref($eprint->[0]) );
        }

        my $repo = $eprint->[0]->repository;
	my $chunk = $repo->make_doc_fragment;
	return $chunk unless( $eprint->[0]->is_set( "abstract" ) );
	my $value = $eprint->[0]->get_value( "abstract" );

	if( length( $value ) <= $DEFAULT_ABS_CHARS )
	{
		$chunk->appendChild( $repo->make_text( $value ) );
	}
	else
	{
		my $first_n = substr( $value, 0, $DEFAULT_ABS_CHARS );
		$first_n .= "...";
		$chunk->appendChild( $repo->make_text( $first_n ) );
	}

        return [ $chunk, "XHTML"  ];
}

}


