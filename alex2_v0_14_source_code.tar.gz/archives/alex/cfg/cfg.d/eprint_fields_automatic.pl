
$c->{set_eprint_automatic_fields} = sub
{
	my( $eprint ) = @_;

	my $type = $eprint->value( "type" );
	if( $type eq "monograph" || $type eq "thesis" )
	{
		unless( $eprint->is_set( "institution" ) )
		{
 			# This is a handy place to make monographs and thesis default to
			# your insitution
			#
			# $eprint->set_value( "institution", "University of Southampton" );
		}
	}

	if( $type eq "patent" )
	{
		$eprint->set_value( "ispublished", "pub" );
		# patents are always published!
	}

	if( $type eq "thesis" && !$eprint->is_set( "ispublished" ) )
	{
		$eprint->set_value( "ispublished", "unpub" );
		# thesis are usually unpublished.
	}

	my @docs = $eprint->get_all_documents();
	my $textstatus = "none";
	if( scalar @docs > 0 )
	{
		foreach my $doc ( @docs )
		{
			if( !$doc->is_public )
			{
				$textstatus = "restricted";
				last;
			}
			$textstatus = "public" unless $doc->has_relation( undef, "isBookCover" );
		}
	}
	$eprint->set_value( "full_text_status", $textstatus );

	my $isbn_changed = 0;
	my @keys = keys %{$eprint->{changed}};
	foreach my $key ( @keys )
	{
		$isbn_changed++ if $key eq 'isbn';
	}
	if ( $isbn_changed )
	{
		my $book_cover_found = 0;
		if( scalar @docs > 0 )
		{
			foreach my $doc ( @docs )
			{
				$book_cover_found++ if $doc->has_relation( undef, "isBookCover" );
			}
		}
		if ( $eprint->is_set( "isbn" ) && !$book_cover_found )
		{
			$eprint->repository->call( "find_book_cover", $eprint );
		}
	}

	#update the divisions
	my $alex_ids = {};
	my $unique_div_vals = {};
	my $creators = $eprint->get_value( "creators" );
	foreach my $creator ( @$creators )
	{
		my $id = $creator->{ "alex_user_id" };
		$alex_ids->{$id}++ if $id;
	}
	my $user_ds = $eprint->repository->dataset( "user" );
	foreach my $uid ( keys %$alex_ids )
	{
		my $user = $user_ds->dataobj( $uid );
		next unless $user;
		my $user_vals  = $user->get_value( "divisions" );
		foreach my $division ( @$user_vals ) 
		{
			$unique_div_vals->{$division}++;
		}
	} 
	
	my @new_divs = keys %$unique_div_vals;
	$eprint->set_value( "divisions", \@new_divs );

};

