#
# modifications to the default workflow
#

$c->{skip_buffer} = 1;

