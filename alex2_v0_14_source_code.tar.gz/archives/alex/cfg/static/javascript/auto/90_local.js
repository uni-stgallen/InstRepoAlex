
/* 
 * This javascript file will be loaded after all the system files.
 * (so other javascript functions will already be loaded)
 * 
 * Javascript files are loaded in alphabetic order, hence the "90" 
 * in the filename to force it to load after the other files!
 * 
 * To totally replace a system js file, create a file of the same 
 * name in this directory. eg. 50_preview.js
 * 
*/

function toggleMainNavi() {
   var home_nav = document.getElementById("main_nav_home");
   var pubs_nav = document.getElementById("main_nav_pubs");
   var proj_nav = document.getElementById("main_nav_proj");
   var peop_nav = document.getElementById("main_nav_people");
   var url = window.location.href;
   var home_found = url.indexOf( "/index.html" );
   var pubs_found = url.indexOf( "/publications" );
   var profile_found = url.indexOf( "/persons" );
   var project_found = url.indexOf( "dataset=project" );
   // if we are not logged in then the the url might be the view
   if ( project_found < 1 ) {
      project_found = url.indexOf( "/pro" );
   }
   if ( profile_found < 1 ) {
      profile_found = url.indexOf( "Homepage_Alex" );
   }
   if ( profile_found < 1 ) {
      profile_found = url.indexOf( "user_" );
   }


   // clear the seletion
   if ( null != home_nav ) {
      home_nav.removeAttribute("class");
   }
   if ( null != pubs_nav ) {
      pubs_nav.removeAttribute("class");
   }
   if ( null != peop_nav ) {
      peop_nav.removeAttribute("class");
   }
   if ( null != proj_nav ) {
      proj_nav.removeAttribute("class");
   }
 
   if ( project_found > 1 && null != proj_nav ) {
      proj_nav.className = "selected";
   } else if ( profile_found > 1  && null != peop_nav ) {
      peop_nav.className = "selected";
   } else if ( pubs_found > 1 && null != pubs_nav ) {
      pubs_nav.className = "selected";
   } else {
   // } else if ( home_found > 1 ) {
      if ( null != home_nav ) {
         home_nav.className = "selected";
      }
   }
}

