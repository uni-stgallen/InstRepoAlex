var Component_Field = Class.create({
	prefix: null,

	initialize: function(prefix) {
		this.prefix = prefix;
		this.root = $(this.prefix);
		this.form = this.root.up ('form');

		this.root.eprints = this;

		this.initialize_internal( this.root );
	},
	initialize_internal: function( root ) {
		root.select ('input.epjs_ajax').each ((function(input) {
			if (input.type == 'image' ) {
				var attr = input.attributesHash ();
				attr['href'] = 'javascript:';
				var link = new Element ('a', attr);
				var img = new Element ('img', {
					src: attr['src']
				});
				link.appendChild (img);
				input.replace (link);
				input = link;
			}
			else {
				var attr = input.attributesHash();
				attr['type'] = 'button';

				var button = new Element ('input', attr );
				input.replace (button);
				input = button;
			}
			input.observe( 'click', this.internal.bindAsEventListener (this, input) );
		}).bind (this));

	},
	internal: function(e, input) {

		var params = serialize_form (this.form);

		params['component'] = this.prefix;
		params[input.name] = input.value;
		params[this.prefix + '_export'] = 1;
		
		var url = eprints_http_cgiroot + '/users/home';

		var component = this.root;

		var rel = null;

		if( typeof( input.getAttribute ) != 'undefined' )
			rel = input.getAttribute( 'rel' );

		if( rel != null && rel == 'interactive' )
		{
			// interactive mode = a Dialog Box is displayed
			new Ajax.Request(url, {
				method: 'post',
				onException: function(req, e) {
					throw e;
				},
				onSuccess: (function(transport) {
					var dbox = new EPJS_DialogBox( {
						'content': transport.responseText,
						'buttons': [],
						'min_width': 670
					});

					var form = dbox.dialog.down( 'form' );
					if (form != null && !form.onsubmit)
					{
						form.onsubmit = function() { return false; };
						form.select ('input[type="submit"]', 'input[type="image"]').each ((function (input) {
							input.observe ('click',
								this.stop.bindAsEventListener(this, input, dbox)
							);
						}).bind(this));
					}
					
					this.initialize_internal( dbox.dialog );

				}).bind (this),
				parameters: params,
				evalScripts: true
			});

			return;
		}

		var container = $(this.prefix + '_content');

		this.loading( container );

		new Ajax.Updater(container, url, {
			method: this.form.method,
			onComplete: (function() {
				this.initialize_internal( this.root );
			}).bind (this),
			parameters: params,
			evalScripts: true
		});
	},

	loading: function( container ) {

		if( container == null || container.firstDescendant() == null )
			return;

		container.firstDescendant().insert( { 'before': new Element( 'img', {
			src: eprints_http_root + '/style/images/loading.gif',
			style: 'position: absolute;'
		} ) } );
	},

        stop: function(event) {

		if( event != null )
			Event.stop(event);

		var data = $A(arguments);
		var input = data[1];
		var dbox = data[2];
	
                var form = input.up ('form');
                var params = serialize_form( form );

                params[input.name] = 1;
                params['export'] = 1;

                var url = eprints_http_cgiroot + '/users/home';
                new Ajax.Request(url, {
                        method: form.method,
                        onException: function(req, e) {
                                throw e;
                        },
                        onSuccess: (function(transport) {
                                var json = transport.responseJSON;
                                if (!json)
                                {
                                        alert ('Expected JSON but got: ' + transport.responseText);
                                        return;
                                }

if( json.insert != null )
{
	var targetElId = json.insert_to;
	if( targetElId != null )
	{
		$( targetElId ).update( json.insert );
		$( targetElId ).show();
		this.initialize_internal( $( targetElId ) );
	}
}

				if( json.stop != null && json.stop )
				{
					// tmp test
					 dbox.hide();

					if( json.action != null && json.action == 'cancel' )
						return;

					this.reload_component();

					// OR! shall we call a local callback method? 
					// this.action( $json.action )
					// ALTHOUGH it's probably the Dialog that's got the callbacks?
					// this.dbox.action( $json.action );
				}
                        }).bind (this),
                        parameters: params,
			evalScripts: true
                });
        },

	// The methods below are accessible via:
	// $( 'c4' ).eprints.{method_name}();
	//
	// If coded within a Component plugin, it will look like:
	// \$( $self->{prefix} ).eprints.{method_name}();

	// This will call Screen::EPrint::Edit::action_save_component()
	save_component: function() {
		this.internal( null, { name: '_action_save_component', value: '' } );
	},
	
	reload_component: function() {
		this.internal( null, { name: '_action_null', value: '' } );
	}
});

