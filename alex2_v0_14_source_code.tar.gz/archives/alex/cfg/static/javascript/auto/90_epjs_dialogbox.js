// Creates a Dialog Box with overlay.
// 
// Input params: 
//	EITHER an "id" (the "id" of the element which will be the content of the popup), 
//	OR raw HTML passed through 'content'
//
//	Optional:
//	- 'show' (true/false): show dialog box upon creation
//	- 'callback' (function): a function to call upon deletion of the dialog box
//	- 'style' (true/false, default true): tells to re-use EPrints default Workflow CSS
//	- 'title' (string/text): an optional Title || 'EPrints' 
//	- 'show_title' (true/false, default true)
//	- 'min_height' / 'min_width': adjusts the (min) size of the box
//	- 'buttons' (default 'ok'): which buttons to show (in the form: buttons: [ { type: 'ok', label: 'OK' }, { type: 'cancel', label: 'Cancel' } ]


// Overlays are used by the EPJS_DialogBox class.
var EPJS_Overlay_zIndex = 100;
var EPJS_Overlay = Class.create({

	overlayEl: null,
	zIndex: 0,

	initialize: function( el ) {
		this.zIndex = EPJS_Overlay_zIndex;
		EPJS_Overlay_zIndex += 2;
	
		this.body = this.getBody();
		this.makeOverlay();

		if( el != null )
		{
			// Overlay will call el.hide():

			// if the user clicks on the overlay
			this.overlayEl.observe( 'click', el.hide.bindAsEventListener(el) );

			// (we need to cache the handler, in order to be able to remove it later - see http://prototypejs.org/api/event/stopobserving)
			this.eventHandler = this.keyPressed.bindAsEventListener(this);

			// if the user presses 'Esc'
			Event.observe( document, 'keypress', this.eventHandler );
		}
	},

	keyPressed: function(event) {

		// ignore or action 'Enter/Return' being pressed

                if( Event.KEY_RETURN == event.keyCode )
                {
			var target = event.target;
			if ( target.name == "dlg_family_name" ||
                             target.name == "dlg_given_name" ||
			     target.name == "dlg_orcid" ||
                             target.name == "dlg_unibeid" ) {
			 
				var form = event.target.up("form");
				var children = form.select('input');
				for (var i=0; i<children.length; i++) {
					var child = children[i];
					if (child.name == "_action_search" ) { 
						child.click();
						break;
					}
				}

				Event.stop( event );

			} else if ( target.name == "my_selected_staff_id" ||
				    target.name == "add_internal_popup_contributors_type" ) {
			 
				var form = event.target.up("form");
				var children = form.select('input');
				for (var i=0; i<children.length; i++) {
					var child = children[i];
					if (child.name == "_action_select" ) { 
						child.click();
						break;
					}
				}

				Event.stop( event );
	
			} else if ( target.name == "ext_dlg_family_name" ||
                                    target.name == "ext_dlg_given_name" || 
			            target.name == "ext_dlg_orcid" ||
				    target.name == "add_external_popup_contributors_type" ) {
			 
				var form = event.target.up("form");
				var children = form.select('input');
				for (var i=0; i<children.length; i++) {
					var child = children[i];
					if (child.name == "_action_save" ) { 
						child.click();
						break;
					}
				}

				Event.stop( event );

			} else if ( target.name == "edit_dlg_family_name" ||
                                    target.name == "edit_dlg_given_name" || 
			            target.name == "edit_dlg_orcid" ) {
			 
				var form = event.target.up("form");
				var children = form.select('input');
				for (var i=0; i<children.length; i++) {
					var child = children[i];
					if (child.name == "_action_save" ) { 
						child.click();
						break;
					}
				}

				Event.stop( event );
	
			} else {
				Event.stop( event );
				this.overlayEl.click();
			}
                        return true;
                }
		else if( Event.KEY_ESC == event.keyCode )
		{
			Event.stop( event );
			this.overlayEl.click();
			return true;
		}
		return false;
	},
	
	getBody: function() {
	
		var zbody = document.getElementsByTagName( 'body' );
		if( zbody != null && zbody.length > 0 )
			return zbody[0];

		return null;
	},
		
	makeOverlay: function() {

		this.overlayEl = $( 'epjs_dialogbox_overlay_' + this.zIndex );

		if( this.overlayEl == null )
		{
			this.overlayEl = new Element( 'div', { 'id': 'epjs_dialogbox_overlay_' + this.zIndex } );
			this.overlayEl.setStyle( {
//				'position': 'absolute',
				'position': 'fixed',
				'top': 0,
				'left': 0,
				'zIndex': this.zIndex,
				'width': '100%',
				'height': '100%',
				'backgroundColor': '#400000',
				'display': 'none'
			});
			Element.insert( this.body, { 'top': this.overlayEl } );
			
			// using a marker div at the end to find the page's height
			if( $( 'epjs_dialogbox_end_marker' ) == null )
			{
				this.marker = new Element( 'div', { 'id': 'epjs_dialogbox_end_marker' } );
				Element.insert( this.body, { 'bottom': this.marker } );
			}

			//this.overlayEl.setStyle( { height: $( 'epjs_dialogbox_end_marker' ).offsetTop +100+ 'px' } );
		}
	},

	exit: function() {
		
		Event.stopObserving( document, 'keypress', this.eventHandler );

		if( this.overlayEl != null )
		{
			EPJS_Overlay_zIndex -= 2;
			new Effect.Fade( this.overlayEl, {duration: 0.1});
			this.overlayEl.remove();
		}
	}
});

var EPJS_DialogBox = Class.create({

	min_height: null,
	min_width: 450,
	offset_top: 0,
	button_pressed: 'no_button_pressed',
	buttons: [],		// { type: 'ok', label: 'OK' } ],
	
	initialize: function( params ) {

		this.content = new Element( 'div' );//Element.extend( params.content );
		this.content.update( params.content );

/*
		if( params.id != null )
		{
			if( $( params.id ) == null )
			{
				alert( 'EPJS_DialogBox: invalid "id" parameter.' );
				return false;
			}
			this.content = Element.clone( $( params.id ), 1 );
		}
		else if( params.content != null )
		{
			this.content = new Element( 'div' );
			this.content.update( params.content );
		}
                else if( params.text != null )
                {
                        var div = new Element( 'div', { 'class': 'epjs_messagebox_content' } );
                        var p = new Element( 'p' );
                        p.update( params.text );
                        div.update( p );
			this.content = div;
                }
*/
		if( this.content == null )
		{
			alert( "Missing parameter 'id' or 'content' in EPJS_DialogBox" );
			return false;
		}
		
		this.body = this.getBody();
		if( this.body == null )
		{
			alert( "Failed to retrieve the <body> tag." );
			return false;
		}
	
		if( params.min_width != null )
			this.min_width = params.min_width;		

		if( params.min_height != null )
			this.min_height = params.min_height;
		
		if( params.buttons != null )
			this.buttons = params.buttons;
	
		this.offset_top = document.viewport.getScrollOffsets().top;

		this.callback = params.callback;
		this.title_text = params.title || 'EPrints';
	
		this.style = params.style;
		if( this.style == null )
			this.style = true;

		this.show_title = params.show_title;
		if( this.show_title == null )
			this.show_title = true;

		this.overlay = 	new EPJS_Overlay( this );

		this.registerButtons();

		if( params.show == null || params.show )
			this.show();

		return false;
	},
	
	registerButtons: function() {

		this.content.select ( 'button.epjs_modalbox_button').each ((function(button) {
			var action =button.getAttribute( 'action' );
			if( action != null )
			{
				alert( 'registering action: '+action );
				Event.observe( button, 'click', this.action_button.bindAsEventListener(this, button) );
			}

		}).bind(this));
	},

	makeButtons: function() {

		var buttons_bar = new Element( 'div', { 'class': 'epjs_messagebox_buttons_bar' } );

		var b = this.buttons;

		for( var i=0; i<b.length; i++ )
		{
			buttons_bar.insert( this.makeButton( b[i].type, b[i].label ) );
		}

		return buttons_bar;
	},
 
	makeDialogBox: function() {

// still in use?	
//		this.content.insert( this.makeButtons() );

/*
		if( this.style )
		{
			// re-use EPrints styles
			this.dialog = new Element( 'div', { 'class': 'ep_sr_component' } );
			this.dialog.hide();
		
			if( this.show_title )
			{
				this.title = new Element( 'div', { 'class': 'ep_sr_title_bar' } );
				this.dialog.appendChild( this.title );

				var title_cont = new Element( 'div', { 'class': 'ep_sr_title' } );
				this.title.appendChild( title_cont );

				title_cont.update( this.title_text );
			}
			
			var zcontent = new Element( 'div', { 'class': 'ep_sr_content' } );
			this.content.show();
			zcontent.appendChild( this.content );
			this.dialog.appendChild( zcontent );
		}
		else
*/


		this.dialog = new Element( 'div' );
		this.dialog.update( this.content );
		
		if( this.min_width != null && this.dialog.getWidth() < this.min_width )
			this.dialog.setStyle( { width: this.min_width+'px' } );
		
		if( this.min_height != null && this.dialog.getHeight() < this.min_height )
			this.dialog.setStyle( { height: this.min_height+'px' } );
	
		Element.insert( this.body, { 'top': this.dialog } );
		
		this.dialog.hide();
		this.dialog.show = this.show.bind(this);
		this.dialog.style.position = "fixed";

		var zIndex = parseInt( this.overlay.zIndex ) + 1;
		this.dialog.style.zIndex = zIndex;
		this.dialog.addClassName( 'epjs_modal_box' );
	},
 
	getBody: function() {
	
		var zbody = document.getElementsByTagName( 'body' );
		if( zbody != null && zbody.length > 0 )
			return zbody[0];

		return null;
	},
 
	show: function() {
		
		this.makeDialogBox();

		var screen = this.screenGeometry();
		// fix this.dialog's position
		var h = screen.height || 0;
		var w = screen.width || 0;

		var ideal_top = ( h / 2 - this.dialog.getHeight() / 2 );
		if( ideal_top < 0 )
			ideal_top = 0;

		this.dialog.style.left = ( w / 2 - this.dialog.getWidth() / 2 ) + 'px';
		this.dialog.style.top = ideal_top + 'px';

		new Effect.Appear(this.overlay.overlayEl, {duration: 0.1, from: 0.0, to: 0.3});
		this.dialog.style.display = 'block';
		
		if( h < this.dialog.getHeight() )
		{
			// if the user's screen is too small to display the modal box, let's resize it
			this.dialog.setStyle( { 'height': h+'px', 'overflow': 'scroll' } );
		}
	},

	hide: function() {

		if( this.overlay )
			this.overlay.exit();
		
		if( this.callback )
			this.callback( this );

		if( this.dialog && this.dialog.parentNode )
		{
			this.dialog.style.display = 'none';
			this.dialog.remove();
			this.dialog = null;
		}
	},

	screenGeometry: function() {
		
		var g = {};

		 // the more standards compliant browsers (mozilla/netscape/opera/IE7) use window.innerWidth and window.innerWidth
		 if (typeof window.innerWidth != 'undefined')
		 {
			g.width = window.innerWidth;
			g.height = window.innerHeight;
		 }
		// IE6 in standards compliant mode (i.e. with a valid doctype as the first line in the document)
		 else if (typeof document.documentElement != 'undefined' && typeof document.documentElement.clientWidth != 'undefined' && document.documentElement.clientWidth != 0)
		 {
			g.width = document.documentElement.clientWidth;
			g.height = document.documentElement.clientHeight;
		 }
		 // older versions of IE
		 else
		 {
			g.width = document.getElementsByTagName('body')[0].clientWidth;
			g.height = document.getElementsByTagName('body')[0].clientHeight;
		 }
		 return g;
	},
	
	makeButton: function( type, label, listener ) {

		var button = new Element( 'button', { 'class': 'epjs_messagebox_button epjs_messagebox_button_'+type, 'action': type } );
		button.update( label );
		if( listener != null )
			Event.observe( button, 'click', listener.bindAsEventListener(this, button) );
		else
			Event.observe( button, 'click', this.action_button.bindAsEventListener(this, button) );
		return button;
	},
	
	action_button: function(event) {
		
		if( event != null )
        	        Event.stop( event );

	        var data = $A(arguments);
        	this.button_pressed = data[1].getAttribute( 'action' );

		this.hide();
	}
}); 

var EPJS_MessageBox = Class.create( EPJS_DialogBox, {
        
	initialize: function($super,params) {

		var show = params.show;
		params.show = false;
	
		if( params.text != null )
		{
			var div = new Element( 'div', { 'class': 'epjs_messagebox_content' } );
			var p = new Element( 'p' );
			p.update( params.text );
			div.update( p );
			params.content = div;
			params.id = null;
		}
	
		$super( params );
	
		if( show == null || show )
			this.show();

		return false;
	}
});

var EPJS_ConfirmBox = Class.create( EPJS_DialogBox, {

	buttons: [ { 'type': 'cancel', 'label': 'Cancel' }, { 'type': 'ok', 'label': 'OK' } ],
	default_button: 'cancel'

});

// necessary?
var EPJS_AlertBox = Class.create( EPJS_MessageBox, {

	initialize: function( $super, text ) {
		var p = {};
		p.text = text;
		$super( p );
	}
});

function EPJS_search_wait() {
   var div = $('staff_results');
   div.insert("<p>Searching...</p>");
}


