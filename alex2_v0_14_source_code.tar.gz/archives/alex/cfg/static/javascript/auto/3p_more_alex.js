
document.observe("dom:loaded",function(){
	// Alex summary show more 
	$$(".ppp_summary_show_more").invoke( "on", "click", function(event) {
		$(Event.element(event)).toggleClassName( "ppp_more_hidden" );
		$(Event.element(event)).next(".ppp_summary_show_less").toggleClassName( "ppp_more_hidden" );
		$(Event.element(event)).next(".ppp_summary_more_details").toggleClassName( "ppp_more_hidden" );
	});

	// Alex summary show less 
	$$(".ppp_summary_show_less").invoke( "on", "click", function(event) {
		$(Event.element(event)).toggleClassName( "ppp_more_hidden" );
		$(Event.element(event)).previous(".ppp_summary_show_more").toggleClassName( "ppp_more_hidden" );
		$(Event.element(event)).next(".ppp_summary_more_details").toggleClassName( "ppp_more_hidden" );
	});

});

