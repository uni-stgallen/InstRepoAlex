package EPrints::Plugin::InputForm::Component::Field::Modal::AddDivisions;

use EPrints::Plugin::InputForm::Component::Field::Modal;
@ISA = qw( EPrints::Plugin::InputForm::Component::Field::Modal );

use strict;

sub new
{
	my( $class, %opts ) = @_;

	my $self = $class->SUPER::new( %opts );
	
	$self->{name} = "Add Divisions";
	$self->{visible} = "all";
	$self->{visdepth} = 1;
	
	return $self;
}


sub update_from_form
{
	my( $self, $processor ) = @_;
	my $repo = $self->{repository};
	my $prefix = $self->{prefix};
	my $item = $self->{dataobj};

	my $ibutton = $self->get_internal_button;
	my $ibutton_pressed = $repo->internal_button_pressed; 

	if ( $ibutton =~ m/^divisions_update_button$/ )
	{
		my $alex_ids = {};
		my $creators = $item->get_value( "creators" );
		foreach my $creator ( @$creators )
		{
			my $id = $creator->{ "alex_user_id" };
			$alex_ids->{$id}++ if $id;
		}
		my $ds = $repo->dataset( "user" );
		foreach my $uid ( keys %$alex_ids )
		{
			my $user = $ds->dataobj( $uid );
			next unless $user;
			#foreach my $field ( qw\ divisions subjects \)
			foreach my $field ( qw\ divisions \)
			{
				my $user_vals  = $user->get_value( $field );
				$self->update_item_values( $item, $field, $user_vals );
			}
		} 
	}
	return;
}


sub update_item_values
{
	my ( $self, $item, $field, $values ) = @_;
	return unless $item && $field && $values;
	my $orig = $item->get_value( $field );
	my $unique_vals = {};
	foreach my $val ( @$orig )
	{
		$unique_vals->{$val}++;
	}
	foreach my $val ( @$values )
	{
		$unique_vals->{$val}++;
	}
	my @new_vals = keys %$unique_vals;
	$item->set_value( $field, \@new_vals );
	$item->commit;
	return;
}

sub export_mimetype
{
        my( $self ) = @_;

        my $plugin = $self->note( "action" );
        if( defined($plugin) && $plugin->param( "ajax" ) eq "automatic" )
        {
                return $plugin->export_mimetype;
        }

        return $self->SUPER::export_mimetype();
}

sub export
{
	my( $self ) = @_;

	my $repo = $self->{repository};
	my $frag;

        if( defined(my $plugin = $self->note( "action" )) )
	{
                return unless( $plugin->can_be_viewed() );
                $plugin->properties_from();

                my $title = $plugin->render_title();
                my $modal_content = $plugin->render();

                $frag = $self->render_modal( $modal_content, $title );
	}
	else
	{
		$frag = $self->render_content;
	}
	
	print $repo->xhtml->to_xhtml( $frag );
	$repo->xml->dispose( $frag );
}


sub can_reload { 0 }

sub render_content
{
	my( $self, $surround ) = @_;

	my $repo = $self->{repository};
	my $field = $self->{config}->{field};
	my $item = $self->{dataobj};

	my $frag = $repo->make_element( "div" );

	my $import_button = $repo->make_element("input", 
						type=>"button", 
						class=>"epjs_ajax",
						name => "_internal_".$self->{prefix}."_divisions_update_button",
						value => $self->phrase("divisions_update_button"));
	my $div_update = $frag->appendChild( $repo->make_element("div", style=>"text-align: center;") );
	$div_update->appendChild($import_button);

	$frag->appendChild( $repo->make_javascript( <<EOJ ) );
new Component_Field ('$self->{prefix}');
EOJ

	return $frag;
}

sub render_help
{
	my( $self, $surround ) = @_;

	return $self->html_phrase("help");
}
sub render_title
{
	my( $self, $surround ) = @_;

	return $self->html_phrase( "title" );
}


1;


