package EPrints::Plugin::InputForm::Component::Field::Modal::SherpaRomeo;

use EPrints::Plugin::InputForm::Component::Field::Modal;
@ISA = qw( EPrints::Plugin::InputForm::Component::Field::Modal );

use strict;

sub new
{
	my( $class, %opts ) = @_;

	my $self = $class->SUPER::new( %opts );
	
	$self->{name} = "Sherpa Romeo";
	$self->{visible} = "all";
	$self->{visdepth} = 1;
	
	return $self;
}


sub update_from_form
{
	my( $self, $processor ) = @_;
	my $repo = $self->{repository};
	my $prefix = $self->{prefix};
	my $item = $self->{dataobj};

	my $ibutton = $self->get_internal_button;
	my $ibutton_pressed = $repo->internal_button_pressed; 

	if ( $ibutton =~ m/^sherpa_romeo_check$/ )
	{
	}
	return;
}

sub export_mimetype
{
        my( $self ) = @_;

        my $plugin = $self->note( "action" );
        if( defined($plugin) && $plugin->param( "ajax" ) eq "automatic" )
        {
                return $plugin->export_mimetype;
        }

        return $self->SUPER::export_mimetype();
}

sub export
{
	my( $self ) = @_;

	my $repo = $self->{repository};
	my $frag;

        if( defined(my $plugin = $self->note( "action" )) )
	{
                return unless( $plugin->can_be_viewed() );
                $plugin->properties_from();

                my $title = $plugin->render_title();
                my $modal_content = $plugin->render();

                $frag = $self->render_modal( $modal_content, $title );
	}
	else
	{
		$frag = $self->render_content;
	}
	
	print $repo->xhtml->to_xhtml( $frag );
	$repo->xml->dispose( $frag );
}


sub can_reload { 0 }

sub render_content
{
	my( $self, $surround ) = @_;

	my $repo = $self->{repository};
	my $field = $self->{config}->{field};
	my $item = $self->{dataobj};
	my $target_div_id = "sherpa_romeo_results_".$item->get_id;

	my $frag = $repo->make_doc_fragment;
	my $sherpa_div = $frag->appendChild( $repo->make_element( "div" ) );
	my $table = $sherpa_div->appendChild( $repo->make_element("table", style=>"width: 100%;") );
	my $tr = $table->appendChild( $repo->make_element("tr", style=>"width: 100%;") );
	my $td0 = $tr->appendChild( $repo->make_element("td", style=>"width: 120px; vertical-align: top !important;" ) );
	my $td1 = $tr->appendChild( $repo->make_element("td", style=>"width: auto;" ) );
	my $td2 = $tr->appendChild( $repo->make_element("td", style=>"width: 400px; vertical-align: top !important;" ) );

	my $div0 = $td0->appendChild( $repo->make_element("div", style=>"height: 120px; width: 120px;") );
	my $div_logo = $div0->appendChild( $repo->make_element("div", style=>"height: 60px: width: 115px;; ") );
	my $div_update = $div0->appendChild( $repo->make_element("div", style=>"height: 60px; width: 115px; position: relative;") );
	my $sherpa_link = $div_logo->appendChild( $repo->make_element("a",href => "http://www.sherpa.ac.uk/romeo.php", target=>"_blank" ) );
	$sherpa_link->appendChild( $repo->make_element("img", src=>"/style/images/romeosmall.jpg", 
					width=>"100", height=>"54", alt=>"SHERPA/RoMEO Database", border=>"0", ) );
	my $import_button = $repo->make_element("input", 
						style=>"position: absolute; bottom: 0px;",
						type=>"button", 
						class=>"epjs_ajax",
						name => "_internal_".$self->{prefix}."_sherpa_romeo_check",
						value => $self->phrase("sherpa_romeo_update_button"));
	$div_update->appendChild($import_button);

	my $results_div = $td1->appendChild( $repo->make_element("div", id=>$target_div_id ) );
	$results_div->appendChild( $self->html_phrase( "waiting" ) );
	$results_div->appendChild( $repo->make_element( "BR" ) );

	my $div2 = $td2->appendChild( $repo->make_element("div") );
	$div2->appendChild( $self->html_phrase("sherpa_colours") );

	$frag->appendChild( $repo->make_javascript( <<EOJ ) );
new Component_Field ('$self->{prefix}');
EOJ

	my $id = $item->get_id;

	$frag->appendChild( $repo->make_javascript( <<EOJ ) );
new Ajax.Updater( $target_div_id, '/cgi/sherpa_romeo_lookup', { parameters: { "id":"$id", "mainonly":"yes" } } ); 
EOJ
	return $frag;
}

sub render_help
{
	my( $self, $surround ) = @_;

	return $self->html_phrase("help");
}
sub render_title
{
	my( $self, $surround ) = @_;

	return $self->html_phrase( "title" );
}


1;


