package EPrints::Plugin::InputForm::Component::Field::Modal;

use EPrints;
use EPrints::Plugin::InputForm::Component::Field;
@ISA = ( "EPrints::Plugin::InputForm::Component::Field" );

use strict;

sub new
{
	my( $class, %opts ) = @_;

	my $self = $class->SUPER::new( %opts );
	
	$self->{name} = "Test Popup";
	$self->{visible} = "all";
	$self->{visdepth} = 1;
	return $self;
}

sub parse_config
{
        my( $self, $config_dom ) = @_;

	# will take care of the <field>
	$self->SUPER::parse_config( $config_dom );

	# now for the <modal>
        my @modals = $config_dom->getElementsByTagName( "button" );

	my @modal_ids;
	foreach my $modal (@modals)
	{
		# just need an id
		my $id = $modal->getAttribute( 'screen' );
		next unless( defined $id );	# better error?
		push @modal_ids, $id;
	}

	# should err if scalar( @modal_ids ) == 0
	$self->{config}->{modalids} = \@modal_ids;
}

sub update_from_form
{
	my( $self, $processor ) = @_;
	my $field = $self->{config}->{field};

	my $session = $self->{session};
        if( $session->internal_button_pressed )
        {
                my $internal = $self->get_internal_button;

		my $plugin = $session->plugin( "Screen::$internal" );
		return if( !defined $plugin );
		
		my $return_to = URI->new( $self->{session}->current_url( host => 1 ) );
		$return_to->query_form(
				$processor->screen->hidden_bits
		);

		if( $plugin->param( 'ajax' ) )
		{
			if( $self->wishes_to_export )
			{
				$self->set_note( "action", $plugin );
				$self->set_note( "return_to", $return_to );
				return;
			}
			else
			{
				$return_to->query_form(
						screen => $plugin->get_subtype,
						eprintid => $self->{workflow}->{item}->id,
						return_to => $return_to->query,
				);

				$processor->{redirect} = $return_to;
			}
		}	
	}

	return;
}

sub export_mimetype
{
        my( $self ) = @_;

        my $plugin = $self->note( "action" );
        if( defined($plugin) && $plugin->param( "ajax" ) eq "automatic" )
        {
                return $plugin->export_mimetype;
        }

        return $self->SUPER::export_mimetype();
}

sub export
{
	my( $self ) = @_;

	my $frag;

        if( defined(my $plugin = $self->note( "action" )) )
	{
		return unless( $plugin->can_be_viewed() );
		$plugin->properties_from();

		my $title = $plugin->render_title();
		my $modal_content = $plugin->render();

		$frag = $self->render_modal( $modal_content, $title );
	}
	else
	{
		$frag = $self->render_content;
	}
	
	print $self->{session}->xhtml->to_xhtml( $frag );
	$self->{session}->xml->dispose( $frag );
}

sub render_content
{
	my( $self, $surround ) = @_;

        my $repo = $self->{repository};
	my $frag = $self->SUPER::render_content( $surround );

	$frag->appendChild( $self->render_modal_buttons() );

        $frag->appendChild( $self->{session}->make_javascript( <<EOJ ) );
	new Component_Field ('$self->{prefix}');
EOJ

	return $frag;
}

sub render_modal_buttons
{
	my( $self ) = @_;

	my $frag = $self->{session}->make_doc_fragment;

	my $buttons_bar = $self->{session}->make_element( 'div', class => 'ep_form_button_bar', style => 'margin:0' );

	my $done_any = 0;
	# note that a modal_id is actually a Screen id
	foreach my $modal_id ( @{ $self->{config}->{modalids} || [] } )
	{
		my $modal = $self->{session}->plugin( "Screen::EPrint::Dialog::$modal_id" ) or next;
		$buttons_bar->appendChild( $modal->modal_link( $self->{prefix} ) );
		$done_any = 1;
	}

	$frag->appendChild( $buttons_bar ) if( $done_any );

	return $frag;
}

sub can_reload { 1 }

sub is_collapsed { 0 }

# renders a modal box
# note that buttons / $self->{buttons} is not currently used
sub render_modal
{
	my( $self, $content, $title ) = @_;

	my $frag = $self->{session}->make_doc_fragment;

	if( defined $title )
	{
	        my $title_bar = $frag->appendChild( $self->{session}->make_element( "div", class=>"ep_sr_title_bar" ) );
        	my $title_div = $title_bar->appendChild( $self->{session}->make_element( "div", class=>"ep_sr_title" ) );

		$title_div->appendChild( $title );
	}

	$frag->appendChild( $content );

	if( EPrints::Utils::is_set( $self->{buttons} ) && 0 )
	{
		my $buttons_bar = $content->appendChild( $self->{session}->make_element( 'div', class => 'ep_sr_buttons_bar' ) );

		foreach my $button_id ( @{ $self->{buttons} } )
		{
			my $button = $buttons_bar->appendChild( $self->{session}->make_element( 'button', class => 'epjs_modalbox_button', id => $self->{prefix}."_buttons_$button_id", action => $button_id ) );

			if( defined $self->{actions}->{$button_id} )
			{
				my $action = $self->{actions}->{$button_id};
				$button->setAttribute( 'onclick', EPrints::Utils::js_string( "$action; return false;" ) );
			}

			$button->appendChild( $self->html_phrase( "button:$button_id" ) );
		}
	}

	return $frag
}

1;
