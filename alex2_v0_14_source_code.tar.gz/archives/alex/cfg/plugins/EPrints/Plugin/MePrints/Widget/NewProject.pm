package EPrints::Plugin::MePrints::Widget::NewProject;

use EPrints::Plugin::MePrints::Widget;
@ISA = ( 'EPrints::Plugin::MePrints::Widget' );

use strict;

sub new
{

	my( $class, %params ) = @_;

	my $self = $class->SUPER::new( %params );
	
	$self->{name} = "EPrints Profile System: New Project";
	$self->{visible} = "all";
	$self->{advertise} = 1;

	if( defined $self->{session} && defined $self->{session}->current_user )
	{
		unless( $self->{session}->current_user->has_role( 'project-deposit' ) )
		{
			$self->{enable} = 0;
		}
	}

	return $self;

}

sub render_content
{
	my( $self ) = @_;

	my $session = $self->{session};
	my $user = $self->{user};
	my $id = "NewProject";

	my $frag = $session->make_doc_fragment;

	my $form = $session->render_form( "POST", $session->get_repository->get_conf( "rel_path" )."/cgi/users/home");

	my $hidden_field = $session->make_element("input", "name"=>"screen", "id"=>"screen", "value"=>"User::Homepage_Alex", "type"=>"hidden");
	$form->appendChild( $hidden_field );

	$hidden_field = $session->make_element("input", "name"=>"widget", "id"=>"widget", "value"=>"MePrints::Widget::NewProject", "type"=>"hidden");
	$form->appendChild( $hidden_field );

	$form->appendChild( $session->render_action_buttons(
		_class => "ep_form_button_bar",
		newproject => $self->phrase( "new_project" ) ));

	$frag->appendChild( $form );

	return $frag;

}

sub allow_newproject 
{
	my ( $self ) = @_;
	return 1; 
}

sub action_newproject
{
	my ( $self ) = @_;
	my $session = $self->{session};

	my $ds = $session->get_repository->get_dataset( 'project' );
	my $project_data = {
		 	"userid" => $session->current_user->get_id(),
	};
	my $project = $ds->create_object( $session, $project_data );

	unless( defined $project )
	{
		return;
	}

	$self->{redirect} = $session->get_repository->get_conf( "rel_path" ).'/cgi/users/home?screen=Workflow%3A%3AEdit&dataset=project&dataobj='.$project->get_id();

	return;
}


1;
