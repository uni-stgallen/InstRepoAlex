package EPrints::Plugin::MePrints::MePrintsHandler;

use strict;
use warnings;

our @ISA = qw/ EPrints::Plugin /;

use utf8;
use EPrints;
use EPrints::Apache::AnApache;

sub handler
{
	my( $r ) = @_;

	my $uri = $r->uri;
	$uri = Encode::decode_utf8($uri);

	my $repository;
	my $user;

	if( $uri =~ m! ^\/(publications|Publikationen)\/(.*)$ !x ) 
	{
		$repository = $EPrints::HANDLE->current_repository;
		return DECLINED if( !defined $repository );

		# MePrints enabled for this repo?
		return DECLINED unless( $repository->config( "meprints_enabled" ) );

		my $user_ds = $repository->dataset( "user" );
		my $name_str = $2;
		if ( $name_str =~ /(.*)_(.*)/ )
		{
			my $results = $user_ds->search(
				filters => [ { meta_fields => [qw( alex_url_name )], value => $name_str, match => "EX" }, ]
			);
			$user = $results->item( 0 ) if $results->count;
			if ( $user && $user->get_value( "alex_user_id" ) )
			{
				my $alex_user_id = $user->get_value( "alex_user_id" );
				my $page = $repository->config( "base_url" )."/view/pub_alex_user_id/".$alex_user_id.".html";
        			EPrints::Apache::AnApache::send_status_line( $r, 303, "See Other" );
        			EPrints::Apache::AnApache::header_out( $r, "Location", $page );
        			EPrints::Apache::AnApache::send_http_header( $r );
        			return DONE;
			}
			else
			{
				return DECLINED;
			}
		} 
		elsif ( $name_str =~ /([0-9]+)/ )
		{
			my $page = $repository->config( "base_url" )."/".$1;
       			EPrints::Apache::AnApache::send_status_line( $r, 303, "See Other" );
       			EPrints::Apache::AnApache::header_out( $r, "Location", $page );
       			EPrints::Apache::AnApache::send_http_header( $r );
       			return DONE;
		}
		else
		{
			print STDERR "MePrintsHandler::handler no match for name_str[".$name_str."] \n";
			return DECLINED;
		}
	}
	elsif( $uri =~ m! ^\/(projects|Projekte)\/(.*)$ !x )
	{
		$repository = $EPrints::HANDLE->current_repository;
		return DECLINED if( !defined $repository );

		# MePrints enabled for this repo?
		return DECLINED unless( $repository->config( "meprints_enabled" ) );

		my $user_ds = $repository->dataset( "user" );
		my $name_str = $2;
		if ( $name_str =~ /(.*)_(.*)/ )
		{
			my $results = $user_ds->search(
				filters => [ { meta_fields => [qw( alex_url_name )], value => $name_str, match => "EX" }, ]
			);
			$user = $results->item( 0 ) if $results->count;
			if ( $user && $user->get_value( "alex_user_id" ) )
			{
				my $alex_user_id = $user->get_value( "alex_user_id" );
				my $page = $repository->config( "base_url" )."/view/pro_alex_user_id/".$alex_user_id.".html";
        			EPrints::Apache::AnApache::send_status_line( $r, 303, "See Other" );
        			EPrints::Apache::AnApache::header_out( $r, "Location", $page );
        			EPrints::Apache::AnApache::send_http_header( $r );
        			return DONE;
			}
			else
			{
				return DECLINED;
			}
		} 
		elsif ( $name_str =~ /([0-9]+)/ )
		{
			my $page = $repository->config( "base_url" )."/id/project/".$1;
       			EPrints::Apache::AnApache::send_status_line( $r, 303, "See Other" );
       			EPrints::Apache::AnApache::header_out( $r, "Location", $page );
       			EPrints::Apache::AnApache::send_http_header( $r );
       			return DONE;
		}
		else
		{
			print STDERR "MePrintsHandler::handler no match for name_str[".$name_str."] \n";
			return DECLINED;
		}
	}
	elsif( $uri =~ m! ^\/(persons|Personen)\/(.*)$ !x )
	{
		$repository = $EPrints::HANDLE->current_repository;
		return DECLINED if( !defined $repository );

		# MePrints enabled for this repo?
		return DECLINED unless( $repository->config( "meprints_enabled" ) );

		my $user_ds = $repository->dataset( "user" );
		my $name_str = $2;
		if ( $name_str =~ /(.*)_(.*)/ )
		{
			my $results = $user_ds->search(
				filters => [ { meta_fields => [qw( alex_url_name )], value => $name_str, match => "EX" }, ]
			);
			$user = $results->item( 0 ) if $results->count;
		} 
		elsif ( $name_str =~ /([0-9]+)/ )
		{
			$user = $repository->user( $1 );
		}
		else
		{
			print STDERR "MePrintsHandler::handler no match for name_str[".$name_str."] \n";
		}
	}
	elsif( $uri =~ m! ^\/profile\/([0-9a-zA-Z]+)(.*)$ !x  )
	{
		$repository = $EPrints::HANDLE->current_repository;
		return DECLINED if( !defined $repository );

		# MePrints enabled for this repo?
		return DECLINED unless( $repository->config( "meprints_enabled" ) );

		my $user_ds = $repository->dataset( "user" );
		my $user_identifier = $1;

		if( $user_identifier =~ m! ^([0-9]+)$ !x )
		{
			# Handle the userid.
			$user = $repository->user( $1 );
		}
	}
		
	if( defined $user )
	{
		if( $user->can_request_view_profile( $repository ) )
		{
			my $alex_user_id = $user->get_value( "alex_user_id" );

			&update( $repository, $user );
			my $page = $user->localpath."/index.html";

			if( -e $page )
			{
				$r->pnotes( user => $user );
				$r->filename( $page );
				EPrints::Apache::Template::handler( $r ); 
				return OK;
			}
		}
		else
		{
			my $page = $repository->config( "rel_path" )."/private.html";

        		EPrints::Apache::AnApache::send_status_line( $r, 303, "See Other" );
        		EPrints::Apache::AnApache::header_out( $r, "Location", $page );
        		EPrints::Apache::AnApache::send_http_header( $r );
        		return DONE;
		}
	}
	
	# Since the user has not been found they do not exist.
	# As a user profile was requested it is not appropriate
	# to continue to attempt parsing. The lack of any return
	# raises a 404 error which is handled in the standard 
	# way.

	return DECLINED;
	
}

sub update
{
	my( $repository, $user ) = @_;

	return unless $user;
	my $hsg_id = $user->get_value( "hsg_entity_id" );
	if ( $hsg_id )
	{
		my $update_photo = 0;
		my $updated = $repository->call( "ppm_update_user_by_admin", $repository, $hsg_id, $user, $update_photo );
	}

	my $targetfile = $user->localpath()."/index.html";

# Always regenerate the user profile
#
#	# if targetfile does not exist, we need to generate the profile
#	if( -e $targetfile )
#	{
#		my $timestampfile = $repository->config( "variables_path" )."/meprints.timestamp";
#		my $need_to_update = 0;
#		if( -e $timestampfile )
#		{
#			my $poketime = (stat( $timestampfile ))[9];
#			my $targettime = (stat( $targetfile ))[9];
#			if( $targettime < $poketime ) { $need_to_update = 1; }
#		}
#
#		return unless $need_to_update;
#	}
	$user->generate_static();
}

1;
