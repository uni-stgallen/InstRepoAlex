package EPrints::Plugin::MePrints::Widget::LatestAdditions;

use EPrints::Plugin::MePrints::Widget;
@ISA = ( 'EPrints::Plugin::MePrints::Widget' );

use strict;

sub new
{
	
	my( $class, %params ) = @_;
	
	my $self = $class->SUPER::new( %params );
	
	if ( !$self->{session} )
	{
		$self->{session} = $self->{processor}->{session};
	}

	$self->{name} = "EPrints Profile System: Latest List Widget";
	$self->{visible} = "all";
	$self->{advertise} = 1;
	$self->{max_display} = 10;

        if( defined $self->{session} && defined $self->{session}->current_user )
        {
                unless( $self->{session}->current_user->has_role( 'deposit' ) )
                {
                        $self->{enable} = 0;
                }
        }
	
	return $self;
}

sub render_content
{
	my( $self ) = @_;

	my $session = $self->{session};
	my $user = $self->{user};

	my $frag = $session->make_doc_fragment;

	my $projects = $session->call( "get_projects_for_contributor", $session, $user );
	$projects->reorder( 'datestamp' );
	my $items = $session->call( "get_publications_for_contributor", $session, $user );
	$items->reorder( 'datestamp' );

	if( $items->count || $projects->count )
	{
		my $itemlist = $session->make_element( "ol" );

		my @eps =  $items->get_records ( 0, $self->{max_display} );
		my @prs =  $projects->get_records ( 0, $self->{max_display} );
		my $next_e = 0;
		my $next_p = 0;
		my $max = scalar @eps + scalar @prs;
		$max = $self->{max_display} if $max > $self->{max_display};
		for( my $i=0; $i<$max; $i++ )
		{
			my $li = $itemlist->appendChild( $session->make_element( 'li' ) );

			my $this_ep = $eps[$next_e];
			my $ep_date = $this_ep->get_value( "datestamp" ) if $this_ep;
			my $this_pr = $prs[$next_p];
			my $pr_date = $this_pr->get_value( "datestamp" ) if $this_pr;
			if ( $pr_date && $ep_date )
			{
				my $pr_epoch = EPrints::Time::datetime_local( EPrints::Time::split_value( $pr_date ) );	
				my $ep_epoch = EPrints::Time::datetime_local( EPrints::Time::split_value( $ep_date ) );	
				if ( $pr_epoch > $ep_epoch )
				{
					$li->appendChild( $this_pr->render_citation_link( "latest_picresult" ) );
					$next_p++;
				}
				else
				{
					$li->appendChild( $this_ep->render_citation_link( "latest_article_pic" ) );
					$next_e++;
				}
			}
			else
			{
				if ( $this_ep )
				{
					$li->appendChild( $this_ep->render_citation_link( "latest_article_pic" ) );
					$next_e++;
				}
				else
				{
					$li->appendChild( $this_pr->render_citation_link( "latest_picresult" ) );
					$next_p++;
				}
			}	
			
		}

		$frag->appendChild( $itemlist );
	}
	else
	{
		$frag->appendChild( $self->html_phrase( "noitems" ) );
	}

	return $frag;

}

1;
