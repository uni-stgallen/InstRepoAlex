=head1 NAME

EPrints::Plugin::Search::XapianCombined

=head1 PARAMETERS

=over 4

=item lang

Override the default language used for stemming.

=item stopwords

An array reference of stop words to use (defaults to English).

=back

=head1 METHODS

=over 4

=cut

package EPrints::Plugin::Search::XapianCombined;

@ISA = qw( EPrints::Plugin::Search::Xapian );

use strict;

sub new
{
	my( $class, %params ) = @_;

	my $self = $class->SUPER::new( %params );

	$self->{name} = "xapian combined";
	$self->{search} = [qw( simple/combined )];
	$self->{qs} = 100; # increase priority so that this plugin is used for "simple/combined"
	$self->{result_order} = 1; # whether to default to showing by engine result order
	if( defined $self->{session} )
	{
		$self->{lang} = $self->{session}->config( "defaultlanguage" );
	}

	$self->{disable} = !EPrints::Utils::require_if_exists( "Search::Xapian" );
	
	return $self;
}

sub can_search
{
	my( $self, $format ) = @_;

	foreach my $match (@{$self->param( "search" ) || []})
	{
		if( $match =~ m# ^(.*)\*$ #x )
		{
			return 1 if substr($format, 0, length($1)) eq $1;
		}
		elsif( $format eq $match )
		{
			return 1;
		}
	}

	return 0;
}


sub execute
{
	my( $self ) = @_;

	my $session = $self->{session};

	my $path = $session->config( "variables_path" ) . "/xapian";
	my $xapian = Search::Xapian::Database->new( $path );

	my $qp = Search::Xapian::QueryParser->new( $xapian );
	$qp->set_stemmer( $self->stemmer );
	$qp->set_stopper( $self->stopper );
	$qp->set_stemming_strategy( Search::Xapian::STEM_SOME() );
	$qp->set_default_op( Search::Xapian::OP_AND() );

	for( qw\ documents title abstract creators_name date name contributors_name description \)
	{
		$qp->add_prefix( $_, "$_:" );
	}

	my $eprint_query = Search::Xapian::Query->new( "_dataset:eprint" );
	my $user_query = Search::Xapian::Query->new( "_dataset:user" );
	my $project_query = Search::Xapian::Query->new( "_dataset:project" );
	
	my $eprint_filters = { 
		eprint_status => 'archive', 
		metadata_visibility => 'show'
	};
	foreach my $field ( keys %$eprint_filters )
	{

		$eprint_query = Search::Xapian::Query->new(
				Search::Xapian::OP_AND(),
				$eprint_query,
				Search::Xapian::Query->new( $field . ':' . $eprint_filters->{$field} )
		);
	}
	if( EPrints::Utils::is_set( $self->{q} ) )
	{
		my $parsed_q = $qp->parse_query( $self->{q},
                                Search::Xapian::FLAG_PHRASE() |
                                Search::Xapian::FLAG_BOOLEAN() | 
                                Search::Xapian::FLAG_LOVEHATE() | 
                                Search::Xapian::FLAG_WILDCARD()
		);
		$eprint_query = Search::Xapian::Query->new( Search::Xapian::OP_AND(), $eprint_query, $parsed_q );
		$user_query = Search::Xapian::Query->new( Search::Xapian::OP_AND(), $user_query, $parsed_q );
		$project_query = Search::Xapian::Query->new( Search::Xapian::OP_AND(), $project_query, $parsed_q );
	}

	my $query = Search::Xapian::Query->new( Search::Xapian::OP_OR(), $eprint_query, $user_query );
	$query = Search::Xapian::Query->new( Search::Xapian::OP_OR(), $query, $project_query );

	my $enq = $xapian->enquire( $query );

	# this is a combined search so it is dificult to order results by anything other than relevance
	$enq->set_sort_by_relevance( );

	my $rs = EPrints::Plugin::Search::Xapian::ResultSet_combined->new(
		session => $session,
		dataset => $self->{dataset},
		enq => $enq,
		count => $enq->get_mset( 0, $xapian->get_doccount )->get_matches_estimated,
		ids => [],
		limit => $self->{limit} );

	return $rs;
}

sub render_description
{
	my( $self ) = @_;

	return $self->{session}->make_text( $self->{q} );
}

sub render_conditions_description
{
	my( $self ) = @_;

	return $self->html_phrase( 'results:title', 
		q => $self->{repository}->make_text( $self->{q} ) 
	);
}

package EPrints::Plugin::Search::Xapian::ResultSet_combined;

our @ISA = qw( EPrints::List );

sub _get_records
{
	my( $self, $offset, $size, $ids_only ) = @_;

	$offset = 0 if !defined $offset;

	if( defined $self->{limit} )
	{
		if( $offset > $self->{limit} )
		{
			$size = 0;
		}
		elsif( !defined $size || $offset+$size > $self->{limit} )
		{
			$size = $self->{limit} - $offset;
		}
	}

	my @ids;
	# as this is a combined search it does not make sense to return a list of ids without
	# knowing what dataset they belong to so just return an empty list.
	return \@ids if $ids_only;

	if( defined $size )
	{
			@ids = $self->_get_dataobjs( $offset, $size );
	}
	else
	{
		# retrieve matches 1000 ids at a time
		while((@ids % 1000) == 0)
		{
			push @ids, $self->_get_dataobjs( $offset, 1000 );
			$offset += 1000;
		}
	}

	return @ids;
}


sub _get_dataobjs
{
	my( $self, $offset, $size, ) = @_;
	my $repo = $self->{session};

 	my @dataobjs;
	my @matches = $self->{enq}->matches( $offset, $size );
	foreach my $match ( @matches )
	{
		my $doc = $match->get_document->get_data();
		next unless $doc =~ /^(.+):(.+)$/;
		my $dataset = $1;
		my $id = $2;

		next unless $dataset;
		my $ds = $repo->dataset( $dataset );
		my $dataobj = $ds->dataobj( $id );
		next unless $dataobj;
		push @dataobjs, $dataobj;
	}  
	return @dataobjs;
}


sub count
{
	my( $self ) = @_;

	return (defined $self->{limit} && $self->{limit} < $self->{count}) ?
		$self->{limit} :
		$self->{count};
}

sub reorder
{
	my( $self, $new_order ) = @_;

	$self->{ids} = $self->ids;

	return $self->SUPER::reorder( $new_order );
}

1;


