=head1 NAME

EPrints::Plugin::Screen::HSG_Alex_Login

=cut

package EPrints::Plugin::Screen::HSG_Alex_Login;

use EPrints::Plugin::Screen;

@ISA = ( 'EPrints::Plugin::Screen' );

use strict;

sub new
{
	my( $class, %params ) = @_;

	my $self = $class->SUPER::new(%params);
	
	$self->{appears} = [
# See cfg.d/dynamic_template.pl
#		{
#			place => "key_tools",
#			position => 100,
#		},
	];
#	$self->{actions} = [qw( login logout )];

	return $self;
}

sub from
{
	my( $self ) = @_;
	my $repo = $self->{session};
	my $host = $repo->config( "host" );
	my $alex_login_url = $repo->config( "alex_login_url" );
	my $uri = $alex_login_url->{$host};
	$self->{processor}->{redirect} = $uri;
}

sub render_action_link
{
	my( $self, %opts ) = @_;
	my $repo = $self->{repository};
	if( defined $repo->current_user )
	{
		return $self->html_phrase( "title:logged_in" );
	}
	else
	{
#print STDERR "Screen::HSG_Alex_Login calling test_for_login repo[$repo]##########################\n";
#		my ( $just_logged_in, $user ) = $self->test_for_login();
#print STDERR "Screen::HSG_Alex_Login called test_for_login got[$just_logged_in] user[".$user."]##########################\n";
#		if( $just_logged_in && defined $user )
#		{
#			$repo->redirect( $repo->config( 'userhome' ) );
#		#	return $self->html_phrase( "title:logged_in" );
#		}

		my $host = $repo->config( "host" );
		my $alex_login_url = $repo->config( "alex_login_url" );
		my $uri = URI->new( $alex_login_url->{$host} );

		my $link = $repo->render_link( $uri );
		$link->appendChild( $self->render_title );
		return $link;
	}
}


sub test_for_login
{
	my( $self ) = @_;

print STDERR "Screen::HSG_Alex_Login test_for_login \n";
	my $repo = $self->{repository};
print STDERR "Screen::HSG_Alex_Login test_for_login repo[$repo]\n";
	return 0 unless $repo;

	my @params = $repo->param();
print STDERR "Screen::HSG_Alex_Login parms[".Data::Dumper::Dumper(\@params)."]\n";
	if ( $params[0] eq "param1" &&
	     $params[1] eq "param2" &&
	     $params[2] eq "param3" &&
	     $params[3] eq "param4" )
	{
		my $HsgEntityId;
		my $SecurityToken; 
		my $actual_time;
		my $sprache;
		my $MD5_Hash;

		if ( $params[4] && $params[4] eq "param5" )
		{
	
			$HsgEntityId = $repo->param( "param1" );
			$SecurityToken = $repo->param( "param2" ); 
			$actual_time = $repo->param( "param3" );
			$sprache = $repo->param( "param4" );
			$MD5_Hash = $repo->param( "param5" );
		}
		else
		{
			$HsgEntityId = "EXTERN";
			$SecurityToken = $repo->param( "param1" ); 
			$actual_time = $repo->param( "param2" );
			$sprache = $repo->param( "param3" );
			$MD5_Hash = $repo->param( "param4" );
		}
print STDERR "Screen::HSG_Alex_Login\n HsgEntityId[$HsgEntityId]\n SecurityToken[$SecurityToken]\n actual_time[$actual_time]\n sprache[$sprache]\n md5[$MD5_Hash]\n";
		my $user = $self->get_user( $HsgEntityId, $SecurityToken, $actual_time, $sprache );
		if ($user)
		{
			EPrints::DataObj::LoginTicket->expire_all( $repo );
			$repo->dataset( "loginticket" )->create_dataobj({
        			userid => $user->id,
			})->set_cookies();

		}
		return ( 1, $user );
	}
	return 0;
}



sub get_user
{
        my( $self, $HsgEntityId, $SecurityToken, $actual_time, $sprache) = @_;

	my $repo = $self->{repository};

print STDERR "HSG_LOGIN: get_user\n";
        unless( defined $HsgEntityId )
        {
print STDERR "HSG_LOGIN: get_user no 'HsgEntityId' param received\n";
                $repo->log( "HSG_LOGIN: no 'HsgEntityId' param received" );
                return undef;
        }
	my $ppm_data = $self->ppm_lookup_person( $HsgEntityId, $SecurityToken, $actual_time, $sprache );

print STDERR "HSG_LOGIN: get_user DO SEARCH ######################################\n";
        my $list = $repo->dataset( 'user' )->search(
                filters => [{ meta_fields => [ 'hsg_entity_id' ], value => "$HsgEntityId", match => 'EX' }]
        );

	my $user;

print STDERR "HSG_LOGIN: get_user got[".$list->count."]\n";
        if( $list->count < 1 )
        {
                $repo->log( "HSG_LOGIN: no user accounts match [$HsgEntityId]" );
                return undef unless $ppm_data;
		my $ds = $repo->dataset( "user" );
		$user = EPrints::DataObj::User::create( $repo, "user" );
		$user->set_value( "hsg_entity_id", $HsgEntityId );
		$user->commit();
print STDERR "HSG_LOGIN: created user[".$user->get_id()."]\n";
        }
        elsif( $list->count > 1 )
        {
        	# more than one match show an error rather than logging in with the wrong user account...
		# could use ppm data to filter but there should not be more than one account with a particular hsgEntityId. 
                $repo->log( "HSG_LOGIN: found ".$list->count." user accounts matching [$HsgEntityId]" );
                return undef;
        }
	else
	{
		$user = $list->item(0);
	}
	$user = $self->update_user_details( $user, $ppm_data );
print STDERR "HSG_LOGIN: get_user return[".$user."] ppm_human_id[".$user->get_value("ppm_human_id")."] name[".Data::Dumper::Dumper($user->get_value("name") )."]\n";
        return $user;
}

sub ppm_lookup_person
{
        my( $self, $HsgEntityId, $SecurityToken, $actual_time, $sprache ) = @_;

	my $repo = $self->{repository};
	my $ppm_data = {};

print STDERR "Screen::HSG_Alex_Login lookup_person\n HsgEntityId[$HsgEntityId]\n SecurityToken[$SecurityToken]\n actual_time[$actual_time]\n sprache[$sprache]\n";

	my $lookup = "http://tools.development.unisg.ch/api/V20100101/Identity/GetIdentity?securityToken=";
	$lookup .= $SecurityToken;
	$lookup .= "&applicationId=cab65a43-c464-433c-ab81-5c8d7cf8599d";
	$lookup .= "&iso=".$HsgEntityId;

print STDERR "lookup[$lookup]\n";

	my $req = HTTP::Request->new( "GET", $lookup );
	$req->header( "accept" => "application/json" );
	my $ua = LWP::UserAgent->new;
	my $response = $ua->request($req);

#print STDERR "response[".Data::Dumper::Dumper( $response )."]\n";
	if ( 200 == $response->code )
	{
print STDERR "GOT 200##################\n";
		my $content = $response->content;
		my $json_vars = JSON::decode_json($content);
print STDERR "\n\n\n\n\njson data[".Data::Dumper::Dumper($json_vars)."]\n";
		return $json_vars->{Data}->{Identity};
	}
	return undef;
}


sub update_user_details
{
	my ( $self, $user, $ppm_data ) = @_;
	return undef unless $user;
	return $user unless $ppm_data;
	my $hsg_entity_id;
	my $human_id;
	foreach my $val ( @{$ppm_data->{Keys}} )
	{
print STDERR "update_user_details set[".$val->{Id}."] to[".$val->{Value}."]\n";
		$hsg_entity_id = $val->{Value} if $val->{Id} eq 'HsgEntityId';
		$human_id = $val->{Value} if $val->{Id} eq 'HumanId';
	}
	$user->set_value( "hsg_entity_id", $hsg_entity_id ) if $hsg_entity_id;
	$user->set_value( "ppm_human_id", $human_id ) if $human_id;
	my $name = {};
	$name->{honourific}  = $ppm_data->{Prefix} if $ppm_data->{Prefix};
	$name->{family} = $ppm_data->{LastName} if $ppm_data->{FirstName};
	$name->{given}  = $ppm_data->{FirstName} if $ppm_data->{LastName};
	$user->set_value( "name", $name ) if $name;
	$user->set_value( "email", $ppm_data->{Email} ) if $ppm_data->{Email};

	unless ( $user->is_set( "username" ) )
	{
		my $initial = substr( $ppm_data->{FirstName}, 0, 1 );
		my $username = $ppm_data->{LastName}.$initial;
		$user->set_value( "username", $username ) if $username;
print STDERR "############################## SETTING USERNAME TO [$username]\n";
	}
print STDERR "update_user_details set[hsg_entity_id] to[".$hsg_entity_id."]\n";
print STDERR "update_user_details set[ppm_human_id] to[".$human_id."]\n";
print STDERR "update_user_details set[name_honourific] to[".$ppm_data->{Prefix}."]\n";
print STDERR "update_user_details set[name_given] to[".$ppm_data->{FirstName}."]\n";
print STDERR "update_user_details set[name_family] to[".$ppm_data->{LastName}."]\n";
print STDERR "update_user_details set[email] to[".$ppm_data->{Email}."]\n";

	my $affiliations = [];
	foreach my $role ( @{$ppm_data->{Roles}} )
	{
print STDERR "update_user_details set[role] to[".$role."]\n";
		push @$affiliations, $role;
	}
	$user->set_value( "affiliations", $affiliations ) if $affiliations;
	$user->commit();
	return $user;
}

1;


