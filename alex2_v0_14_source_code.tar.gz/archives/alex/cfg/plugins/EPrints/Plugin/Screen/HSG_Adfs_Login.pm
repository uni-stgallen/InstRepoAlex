=head1 NAME

EPrints::Plugin::Screen::HSG_Adfs_Login

=cut

package EPrints::Plugin::Screen::HSG_Adfs_Login;

use EPrints::Plugin::Screen;

@ISA = ( 'EPrints::Plugin::Screen' );

use strict;

sub new
{
	my( $class, %params ) = @_;

	my $self = $class->SUPER::new(%params);
	
	$self->{appears} = [
# See cfg.d/dynamic_template.pl
#		{
#			place => "key_tools",
#			position => 100,
#		},
	];
#	$self->{actions} = [qw( login logout )];

	return $self;
}

sub render_action_link
{
	my( $self, %opts ) = @_;
	my $repo = $self->{repository};

	if( defined $repo->current_user )
	{
		return $self->html_phrase( "title:logged_in" );
	}
	else
	{
		my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
		$year += 1900;
		$mon += 1;
		my $mon_str = "";
		$mon_str .= "0" if $mon < 10;
		$mon_str .= "$mon";
		my $date_str = $year."-".$mon_str."-".$mday."T".$hour.":".$min.":".$sec."Z";
		my $adfs_endpoint = $repo->config( "adfs_url" );
		my $uri = URI->new( $adfs_endpoint );
		$uri->query_form(
			wa => $repo->config( "adfs_url_wa" ),
			wct => $date_str,
			wtrealm => $repo->config( "adfs_url_wtrealm" ),
			wctx => $repo->config( "adfs_url_wctx" ),
		);

		my $link = $repo->render_link( $uri );
		$link->appendChild( $self->render_title );
print STDERR "HSG_Adfs_Login returning link [$link]\n";
		return $link;
	}
}



1;


