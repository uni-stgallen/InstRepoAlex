package EPrints::Plugin::Screen::Project_Items;

use EPrints::Plugin::Screen;

@ISA = ( 'EPrints::Plugin::Screen' );

use strict;

sub new
{
	my( $class, %params ) = @_;

	my $self = $class->SUPER::new(%params);

	$self->{appears} = [
		{
			place => "key_tools",
			position => 110,
		}
	];

	return $self;
}

sub properties_from
{
        my( $self ) = @_;
	my $processor = $self->{processor};
	my $session = $self->{session};

	$processor->{dataset} = $session->dataset( "project" );
}


sub can_be_viewed
{
	my( $self ) = @_;

	return 0 unless( defined $self->{session} && defined $self->{session}->current_user );
	my $priv = "projects";
	return $self->allow( $priv );
}

sub render_action_link
{
        my( $self, %opts ) = @_;

        my $repo = $self->{repository};
	my $user = $repo->current_user();
        my $uri = URI->new( $repo->config( "http_url" ) );
	if ( $self->can_be_viewed )
	{
		$uri .= "/cgi/users/home?screen=Project_Listing&dataset=project";
	}
	else
	{
		$uri .= "/projects.html";
	}


        my $link =  $repo->make_element(
                "a",
                href=>$uri,
                id=>"main_nav_proj" );
        $link->appendChild( $self->render_title );

        return $link;
}


1;


