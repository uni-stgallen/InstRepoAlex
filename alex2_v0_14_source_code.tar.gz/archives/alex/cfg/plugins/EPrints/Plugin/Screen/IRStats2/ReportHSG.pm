package EPrints::Plugin::Screen::IRStats2::ReportHSG;

use EPrints::Plugin::Screen::IRStats2::Report;
@ISA = ( 'EPrints::Plugin::Screen::IRStats2::Report' );

use strict;

# Screen::IRStats2::ReportHSG
#
# The screen handling the generation of reports. The main function is to get the context of the query and to pass on the context
#  to the appropriate View plugins
#
# This module updates the default module by modifying the title of the action link

sub new
{
        my( $class, %params ) = @_;

        return $class->SUPER::new(%params);
}

sub render_action_link
{
        my( $self, %opts ) = @_;

        my $uri = URI->new( $self->{session}->config( "http_cgiurl" ) . "/stats/report" );

        my $link = $self->{session}->render_link( $uri );

        # modification to use the default report title for the action link rather than 
        # using the name of the current report.
        #$link->appendChild( $self->render_title );
        $link->appendChild( $self->{session}->html_phrase( "lib/irstats2:report:main" ) );

        return $link;

}



1;

