=head1 NAME

EPrints::Plugin::Screen::User_Listing

=cut

package EPrints::Plugin::Screen::User_Listing;

use EPrints::Plugin::Screen;

@ISA = ( 'EPrints::Plugin::Screen' );

use strict;

sub new
{
	my( $class, %params ) = @_;

	my $self = $class->SUPER::new(%params);

	$self->{appears} = [
	];

	return $self;
}

sub properties_from
{
	my( $self ) = @_;

	my $processor = $self->{processor};
	my $session = $self->{session};

	if( !defined $processor->{dataset} )
	{
			$processor->{"dataset"} = $session->dataset( "user" );
	}

	my $dataset = $processor->{"dataset"};

	my $prev_letter = $session->param( "_selected_letter" );
	my $letter = $session->param( "_select_letter" );
	$letter = $prev_letter unless $letter;
	$processor->{select_letter} = $letter;

	$self->SUPER::properties_from;
}

sub from
{
	my( $self ) = @_;

	my $session = $self->{session};

	my $letter = $self->{processor}->{letter};
	my $search = $self->{processor}->{search};
	my $action = $self->{processor}->{action};
	$action = "" if !defined $action;

	$self->SUPER::from();
}

sub redirect_to_me_url
{
	my( $self ) = @_;

	my $uri = URI->new( $self->SUPER::redirect_to_me_url );
	$uri->query_form(
		$uri->query_form,
		$self->hidden_bits,
	);

	return $uri;
}

sub can_be_viewed
{
	my( $self ) = @_;

	return 1;
}

sub render_title
{
	my( $self ) = @_;

	my $session = $self->{session};

	return $session->html_phrase( "Plugin/Screen/Listing:page_title",
		dataset => $session->html_phrase( "datasetname_".$self->{processor}->{dataset}->id ) );
}

sub render
{
	my( $self ) = @_;

	my $repo = $self->{repository};

	my $chunk = $repo->make_doc_fragment;
	$chunk->appendChild( $self->render_menu() );
	$chunk->appendChild( $self->html_phrase( "list_titles" ) );

	my $ds = $repo->dataset( "user" );
	my $list = $ds->search(  custom_order => "name", 
                                 filters=>[ { meta_fields => [ 'letter' ], value => $self->{processor}->{select_letter}, match=>"EQ" } ] );

	# Paginate list
	my $row = 0;
	my %opts = (
		params => {
			screen => $self->{processor}->{screenid},
#			meta_fields => [ 'name_family' ], 
			value => 'abcdf', 
			match=>"EQ",
			$self->hidden_bits,
		},
                render_result => sub { return $self->render_result_row( @_ ); },

	);

	$opts{page_size} = $self->param( 'page_size' );
	#$opts{page_size} = 3;

	$chunk->appendChild( EPrints::Paginate->paginate_list( $repo, "_listing", $list, %opts ) );

	return $chunk;
}

sub render_result_row
{
        my( $self, $repo, $result, $searchexp, $n ) = @_;

        return $result->render_citation_link( "listing" );
}


sub hidden_bits
{
	my( $self ) = @_;

print STDERR "hidden_bits _select_letter is [".$self->{processor}->{select_letter}."]\n";
	return(
		dataset => $self->{processor}->{dataset}->id,
		_listing_order => $self->{processor}->{search}->{custom_order},
		_selected_letter => $self->{processor}->{select_letter},
		$self->SUPER::hidden_bits,
	);
}

sub render_menu
{
	my ( $self ) = @_;

	my $repo = $self->{repository};
	my $xml = $repo->xml;

	my $selected = $self->{processor}->{select_letter};
	$selected = "a" unless $selected;
	my $menu = $repo->make_element( "div", class=>"ep_columns_add" );
	my $menu_form = $menu->appendChild( $self->render_form );
	foreach my $letter ( 'a'..'z')
	{

		my $id = "user_listing_menu_btn";
		$id .= "_selected" if $letter eq $selected;
		$menu_form->appendChild( $repo->make_element( 
			"input",
			type=>"submit",
			value=>$letter,
			title=>$letter,
			id => $id,
			name => "_select_letter" ) );
	}
	return $menu;
}


1;


