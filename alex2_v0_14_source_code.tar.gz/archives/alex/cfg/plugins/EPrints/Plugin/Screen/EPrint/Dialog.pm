# allows generic Modal/Dialog box "conversation" on the workflow

package EPrints::Plugin::Screen::EPrint::Dialog;

our @ISA = ( 'EPrints::Plugin::Screen::EPrint' );

use strict;
use JSON;

sub redirect_to_me_url
{
	my( $self ) = @_;
	
	return $self->wishes_to_export ? undef : $self->SUPER::redirect_to_me_url;
}

sub wishes_to_export
{
	my( $self ) = @_;

	return $self->{session}->param( "export" );
}

sub export_mimetype { "application/json; charset=UTF-8" }

sub json
{
	my( $self ) = @_;

	# stop: closes the modal box
	# reload: reload the component (for instance if the modal box sets a new value to the EPrint object)
	my $json = { stop => 1, reload => 1 };

	my $action_id = $self->{processor}->{action};
	if( defined $action_id )
	{
		$json->{action} = $action_id;
	}

	return $json;	
}

sub export
{
	my( $self ) = @_;
	#my $plugin = $self->{session}->plugin( "Export::JSON" );
	#print $plugin->output_dataobj( $self->json );
	print JSON->new->utf8(1)->pretty(1)->encode( $self->json );
}

sub action_cancel
{
	my( $self ) = @_;

	$self->{processor}->{redirect} = $self->{processor}->{return_to}
		if !$self->wishes_to_export;
}

sub can_be_viewed
{
	my( $self ) = @_;

	return 0 unless $self->could_obtain_eprint_lock;
	return $self->allow( "eprint/edit" );
}

sub render_title
{
	shift->EPrints::Plugin::Screen::render_title( @_ );
}

sub obtain_lock
{
	my( $self ) = @_;

	return $self->could_obtain_eprint_lock;
}

sub properties_from
{
	my( $self ) = @_;

	$self->SUPER::properties_from;

	my $uri = URI->new( $self->{session}->current_url( host => 1 ) );
	$uri->query( $self->{session}->param( "return_to" ) );
	$self->{processor}->{return_to} = $uri;


	# get hold of the item / dataset / dataobj here - perhaps the "Modal" InputForm component can pass these on
}

sub hidden_bits
{
	my( $self ) = @_;

	return(
		$self->SUPER::hidden_bits,
		return_to => $self->{processor}->{return_to}->query,
	);
}

sub modal_link
{
        my( $self, $prefix, $link_text ) = @_;

        my $ajax = $self->param( 'ajax' );
        return $self->{session}->make_doc_fragment unless( defined $ajax && $ajax eq 'interactive' );

        my $label = $link_text || $self->phrase( 'title' );

	my $compo_prefix = $self->{component_prefix} || $prefix;

        my $button = $self->{session}->render_button(
                class => "ep_form_action_button epjs_ajax",
                name => "_internal_".$compo_prefix."_".$self->get_subtype,
                value => $label,
        );

        $button->setAttribute( 'rel', 'interactive' );

        return $button;
}

1;
