=head1 NAME

EPrints::Plugin::Screen::Project_Listing

=cut

package EPrints::Plugin::Screen::Project_Listing;

use EPrints::Plugin::Screen::Listing;

@ISA = ( 'EPrints::Plugin::Screen::Listing' );

use strict;

sub new
{
	my( $class, %params ) = @_;

	my $self = $class->SUPER::new(%params);

# this plugin is displayed by the redirect in the Project_Items plugin
#	$self->{appears} = [
#		{
#			place => "key_tools",
#			position => 100,
#		}
#	];

	$self->{actions} = [qw/ search newsearch col_left col_right remove_col add_col set_filters reset_filters /];

	return $self;
}

sub properties_from
{
	my( $self ) = @_;

	my $processor = $self->{processor};
	my $session = $self->{session};

	$processor->{dataset} = $session->dataset( "project" );

	$self->SUPER::properties_from();
}



sub can_be_viewed
{
	my( $self ) = @_;

	return 0 unless( defined $self->{session} && defined $self->{session}->current_user );
	my $priv = "projects";
	return $self->allow( $priv );
}


sub perform_search
{
	my( $self ) = @_;

	my $processor = $self->{processor};
	my $search = $processor->{search};

	# dirty hack copied from eprint item list
	my $list = $self->{session}->current_user->editable_projects_list( %$search,
		custom_order => $search->{order}
	);

	return $list;

}



1;


