package EPrints::Plugin::Screen::User::Optivo;

use EPrints::Plugin::Screen;

@ISA = ( 'EPrints::Plugin::Screen' );

use strict;

sub new
{
	my( $class, %params ) = @_;

	my $self = $class->SUPER::new(%params);

	if( defined $self->{session} && !$self->{session}->config( "meprints_enabled" ) )
	{
		return $self;
	}

	$self->{actions} = [qw/ subscribe unsubscribe /];

	$self->{appears} = [
		{
			place => "user_actions",
			position => 1010,
		}
	];
        
	return $self;
}

sub can_be_viewed
{
	my( $self ) = @_;

        return 0 unless( defined $self->{session} && defined $self->{session}->current_user );

	my $user = EPrints::Plugin::MePrints::get_user( $self->{session} );
        return $self->{session}->current_user->allow( 'user/edit', $user );
}

sub properties_from
{
        my( $self ) = @_;

        $self->EPrints::Plugin::Screen::User::Homepage::properties_from;
}

sub redirect_to_me_url
{
        my( $self ) = @_;

        return $self->SUPER::redirect_to_me_url."&userid=".$self->{processor}->{userid};
}

sub allow_subscribe
{
	my( $self ) = @_;

	return $self->can_be_viewed;
}

sub action_subscribe
{
	my( $self ) = @_;

	my $user = $self->{processor}->{user};
	return unless( defined $user );

	my $repo = $self->{repository};
	my $success = $repo->call( "optivo_subscribe", $repo, $user, 1 );
	if ( $success == 200 )
	{
        	$self->{processor}->add_message( "message", $self->html_phrase( "subscribe_sent" ) );
        	$self->{processor}->add_message( "message", $self->html_phrase( "subscribe_success" ) );
	}
	elsif ( $success == -1 )
	{
        	$self->{processor}->add_message( "warning", $self->html_phrase( "subscribe_not_sent" ) );
	}
	else
	{
        	$self->{processor}->add_message( "warning", $self->html_phrase( "subscribe_failed", 
								reason=>$repo->xml->create_text_node( $success ) ) );
	}
	$self->{processor}->{screenid} = "User::Homepage_Alex";
}	

sub allow_unsubscribe
{
	my( $self ) = @_;

	return $self->can_be_viewed;
}

sub action_unsubscribe
{
	my( $self ) = @_;
	
	my $user = $self->{processor}->{user};
	return unless( defined $user );
	
	my $repo = $self->{repository};
	my $success = $repo->call( "optivo_unsubscribe", $repo, $user, 1 );
	if ( $success == 200 )
	{
        	$self->{processor}->add_message( "message", $self->html_phrase( "unsubscribe_sent" ) );
        	$self->{processor}->add_message( "message", $self->html_phrase( "unsubscribe_success" ) );
	}
	elsif ( $success == -1 )
	{
        	$self->{processor}->add_message( "warning", $self->html_phrase( "unsubscribe_not_sent" ) );
	}
	else
	{
        	$self->{processor}->add_message( "warning", $self->html_phrase( "unsubscribe_failed", 
								reason=>$repo->xml->create_text_node( $success ) ) );
	}
	$self->{processor}->{screenid} = "User::Homepage_Alex";
}


sub render
{
        my( $self ) = @_;

        my $session = $self->{session};

	my $chunk = $session->make_doc_fragment;

	my $user = $self->{processor}->{user};
	return $chunk unless( defined $user );

        my $form =  $session->render_form( "post" );
	$chunk->appendChild( $form );

	$form->appendChild( $self->render_hidden_bits );

	my $div = $session->make_element( "div", "class"=>"ed_profilepic_box" );
	$div->appendChild( $self->html_phrase( "optivo_blurb" ) );
	$form->appendChild( $div );
	$form->appendChild( $session->render_hidden_field( "userid", $user->get_id ) );

	my $container = $session->make_element( "div", "style"=>"margin-left:auto;margin-right:auto;margin-top:10px;",align=>"center" );

	$form->appendChild( $self->render_buttons );
	
        return $chunk;
}


sub render_buttons
{
	my( $self ) = @_;

	my %buttons = ( _order=>[], _class=>"ep_form_button_bar" );

	push @{$buttons{_order}}, "subscribe", "unsubscribe";
	$buttons{subscribe} = $self->phrase( "subscribe" );
	$buttons{unsubscribe} = $self->phrase( "unsubscribe" );

	return $self->{session}->render_action_buttons( %buttons );
}

1;


