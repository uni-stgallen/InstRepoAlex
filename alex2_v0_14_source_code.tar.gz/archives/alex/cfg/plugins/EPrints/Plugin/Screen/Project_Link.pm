
=head1 NAME

EPrints::Plugin::Screen::Project_Link
  
=cut
    
package EPrints::Plugin::Screen::Project_Link;
    
use EPrints::Plugin::Screen;
  
@ISA = ( 'EPrints::Plugin::Screen' );
    
use strict;
      
sub new 
{         
        my( $class, %params ) = @_;
      
        my $self = $class->SUPER::new(%params);
        
        $self->{appears} = [
               {
                       place => "main_navigation_link",
                       position => 110,
               },
        ];

        return $self;
}

sub can_be_viewed { 1 }

sub render_title
{
        my( $self ) = @_;
        return $self->SUPER::render_title;
}

sub render_action_link
{
        my( $self, %opts ) = @_;

        my $repo = $self->{repository};
	my $user = $repo->current_user();
        my $uri = URI->new( $repo->config( "http_url" ) );
	if ( $user && $user->allow( "project/edit" ) )
	{
		$uri .= "/cgi/users/home?screen=Listing&dataset=project";
	}
	else
	{
		$uri .= "/view/project/";
	}


        my $link =  $repo->make_element(
                "a",
                href=>$uri,
                id=>"main_nav_proj" );
        $link->appendChild( $self->render_title );

        return $link;
}


1;


