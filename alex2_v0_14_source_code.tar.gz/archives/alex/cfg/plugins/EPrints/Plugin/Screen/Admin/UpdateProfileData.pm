=head1 NAME

EPrints::Plugin::Screen::Admin::UpdateProfileData

=cut

package EPrints::Plugin::Screen::Admin::UpdateProfileData;

@ISA = ( 'EPrints::Plugin::Screen' );

use strict;

sub new
{
	my( $class, %params ) = @_;

	my $self = $class->SUPER::new(%params);
	
	$self->{actions} = [qw/ update_profile /]; 
		
	$self->{appears} = [
		{ 
			place => "admin_actions_system", 
			position => 1440, 
			action => "update_profile",
		},
	];

	return $self;
}

sub allow_update_profile
{
	my( $self ) = @_;

	return $self->allow( "config/regen_abstracts" );
}

sub action_update_profile
{
	my( $self ) = @_;

	my $repo = $self->{repository};
	
        my $file = $repo->get_repository->get_conf( "variables_path" )."/meprints.timestamp";
        unless( open( CHANGEDFILE, ">$file" ) )
        {
                $self->{processor}->add_message( "error",
                        $self->html_phrase( "failed" ) );
                $self->{processor}->{screenid} = "Admin";
                return;
        }
        print CHANGEDFILE "This file last poked at: ".EPrints::Time::human_time()."\n";
        close CHANGEDFILE;


	my $user_ds = $repo->dataset( "user" );
	my $list = $user_ds->search;
	my $update_count = 0;
	my $no_id_count = 0;
	my $no_data_count = 0;
	$list->map( sub {
        	my( $repo, $ds, $user ) = @_;

		my $id = $user->get_value( "hsg_entity_id" );
        	unless( $id )
        	{
			$no_id_count++;
                	next;
        	}
		my $update_photo = 1;
		my $updated = $repo->call( "ppm_update_user_by_admin", $repo, $id, $user, $update_photo );
 
        	unless( $updated )
        	{
			$no_data_count++;
                	next;
        	}
		$update_count++;
	});

       	$self->{processor}->add_message( "message",
               	$self->html_phrase( "ok", 
			updated => $repo->xml->create_text_node($update_count),
			no_id => $repo->xml->create_text_node($no_id_count),
			no_data => $repo->xml->create_text_node($no_data_count),
 		) );
       	$self->{processor}->{screenid} = "Admin";

#	unless( $repo->expire_abstracts() )
#	{
#		$self->{processor}->add_message( "error",
#			$self->html_phrase( "failed" ) );
#		$self->{processor}->{screenid} = "Admin";
#		return;
#	}
	
}	




1;


